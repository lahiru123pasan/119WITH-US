import React, { Component } from "react";

class sidebar extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div>
        <div className="app-sidebar__overlay" data-toggle="sidebar" />
        <aside className="app-sidebar">
          <div className="app-sidebar__user">
            <div
              style={{
                textAlign: "center",
                margin: "auto",
                width: "50%"
              }}
            >
              <img
                src="https://upload.wikimedia.org/wikipedia/en/thumb/1/1d/Sri_Lanka_Police_logo.svg/350px-Sri_Lanka_Police_logo.svg.png"
                width="50"
              />
            </div>
          </div>
          <ul className="app-menu">
            <li>
              <a className="app-menu__item" href="/dashboard">
                <i className="app-menu__icon fa fa-dashboard" />
                <span className="app-menu__label">Dashboard</span>
              </a>
            </li>
            <li className="treeview">
              <a className="app-menu__item" href="#" data-toggle="treeview">
                <i className="app-menu__icon fa fa-laptop" />
                <span className="app-menu__label">Fine Papers</span>
                <i className="treeview-indicator fa fa-angle-right" />
              </a>
              <ul className="treeview-menu">
                <li>
                  <a className="treeview-item" href="/finepaperlistpending">
                    <i className="icon fa fa-circle-o" /> Pending Fine Papers
                  </a>
                </li>
                <li>
                  <a className="treeview-item" href="/finepaperlistpaid">
                    <i className="icon fa fa-circle-o" /> Paid Fine Papers
                  </a>
                </li>
                <li>
                  <a className="treeview-item" href="/finepaperlistexpired">
                    <i className="icon fa fa-circle-o" /> Expired Fine Papers
                  </a>
                </li>
                <li>
                  <a className="treeview-item" href="/efinesearch">
                    <i className="icon fa fa-circle-o" /> Search
                  </a>
                </li>
              </ul>
            </li>
            <li className="treeview">
              <a className="app-menu__item" href="#" data-toggle="treeview">
                <i className="app-menu__icon fa fa-edit" />
                <span className="app-menu__label">Police Officers</span>
                <i className="treeview-indicator fa fa-angle-right" />
              </a>
              <ul className="treeview-menu">
                <li>
                  <a className="treeview-item" href="/policemenlist">
                    <i className="icon fa fa-circle-o" /> Approved Police
                    Officers
                  </a>
                </li>
                <li>
                  <a className="treeview-item" href="/policemenlistpending">
                    <i className="icon fa fa-circle-o" /> Pending Police
                    Officers
                  </a>
                </li>
                <li>
                  <a className="treeview-item" href="/searchpolice">
                    <i className="icon fa fa-circle-o" /> Search Police Officers
                  </a>
                </li>
              </ul>
            </li>
            <li className="treeview">
              <a className="app-menu__item" href="#" data-toggle="treeview">
                <i className="app-menu__icon fa fa-th-list" />
                <span className="app-menu__label">Civilian</span>
                <i className="treeview-indicator fa fa-angle-right" />
              </a>
              <ul className="treeview-menu">
                <li>
                  <a className="treeview-item" href="/civilianlistpending">
                    <i className="icon fa fa-circle-o" /> Civilian List
                    (Pending)
                  </a>
                </li>
                <li>
                  <a className="treeview-item" href="/civilianlist">
                    <i className="icon fa fa-circle-o" /> Civilian List
                  </a>
                </li>
                <li>
                  <a className="treeview-item" href="/civiliansearch">
                    <i className="icon fa fa-circle-o" /> Civilian Search
                  </a>
                </li>
              </ul>
            </li>
            <li className="treeview">
              <a className="app-menu__item" href="#" data-toggle="treeview">
                <i className="app-menu__icon fa fa-th-list" />
                <span className="app-menu__label">Incidents</span>
                <i className="treeview-indicator fa fa-angle-right" />
              </a>
              <ul className="treeview-menu">
                <li>
                  <a className="treeview-item" href="/incidentlist">
                    <i className="icon fa fa-circle-o" /> Incident Reports (Not
                    informed)
                  </a>
                </li>
                <li>
                  <a className="treeview-item" href="/incidentlistinformed">
                    <i className="icon fa fa-circle-o" /> Incident Reports
                    (Informed)
                  </a>
                </li>
              </ul>
            </li>
            <li>
              <a className="app-menu__item" href="/reports">
                <i className="app-menu__icon fa fa-dashboard" />
                <span className="app-menu__label">Reports</span>
              </a>
            </li>
          </ul>
        </aside>
      </div>
    );
  }
}

export default sidebar;
