import React, { Component } from "react";
import Alert from "react-bootstrap/Alert";
import Button from "react-bootstrap/Button";

class header extends Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      message: "Some Error Occured!",
      alertVariant: "danger",
      buttonVariant: "outline-danger"
    };
  }

  render() {
    return (
      <div>
        <Alert
          className="app-header-alert"
          show={this.props.show}
          variant={
            this.props.alertVariant
              ? this.props.alertVariant
              : this.state.alertVariant
          }
        >
          <div className="d-flex justify-content-end">
            <Button
              onClick={() => this.props.handleHide()}
              variant={
                this.props.buttonVariant
                  ? this.props.buttonVariant
                  : this.state.buttonVariant
              }
            >
              <span>&#10005;</span>
            </Button>
          </div>
          <Alert.Heading style={{ marginTop: "-30px" }}>
            {this.props.message ? this.props.message : this.state.message}
          </Alert.Heading>
        </Alert>
        <header
          className="app-header"
          id="app-header"
          style={{ backgroundColor: "#39367E" }}
        >
          <a
            className="app-header__logo"
            href="#"
            style={{ backgroundColor: "#39367E" }}
          >
            E Fine
          </a>
          <a
            className="app-sidebar__toggle"
            href="#"
            data-toggle="sidebar"
            aria-label="Hide Sidebar"
          />
          <ul className="app-nav">
            <li className="dropdown">
              <a
                className="app-nav__item"
                href="#"
                data-toggle="dropdown"
                aria-label="Open Profile Menu"
              >
                <i className="fa fa-user fa-lg" />
              </a>
              <ul className="dropdown-menu settings-menu dropdown-menu-right">
                <li>
                  <a className="dropdown-item" href="/user">
                    <i className="fa fa-user fa-lg" /> Profile
                  </a>
                </li>
                <li>
                  <a className="dropdown-item" href="/">
                    <i className="fa fa-sign-out fa-lg" /> Logout
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </header>
      </div>
    );
  }
}

export default header;
