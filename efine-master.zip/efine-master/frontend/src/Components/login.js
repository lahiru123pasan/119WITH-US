import React, { Component } from "react";
import axios from "axios";
import { error } from "util";

const querystring = require("querystring");

class login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      uname: "",
      pword: "",
      action: "",
      unameError: "none",
      pwError: "none"
    };
  }

  //taking the username input
  handleUnameInput(event) {
    this.setState({
      uname: event.target.value
    });
  }

  //taking the password input
  handlePwordInput(event) {
    this.setState({
      pword: event.target.value
    });
  }

  //submit data to the server for authentication
  handleSubmit(e) {
    e.preventDefault();
    var data = {
      nic: this.state.uname,
      pass: this.state.pword
    };
    //assign the server's IP address and the Port number
    // axios
    //   .post(
    //     `http://45.76.195.117:5000/api/civilian/web/login`,
    //     querystring.stringify(data),
    //     {
    //       headers: {
    //         "Access-Control-Allow-Origin": "*",
    //         "Content-type": "application/x-www-form-urlencoded",
    //         Accept: "application/json"
    //       }
    //     }
    //   )
    //   .then(response => {
    //
    if (data.nic === "admin" && data.pass === "admin") {
      this.setState({
        unameError: "none",
        pwError: "none"
      });
      document.getElementById("form-username").style.borderColor = "#17A2B8";
      document.getElementById("form-password").style.borderColor = "#17A2B8";
      window.location.replace("/dashboard");
    } else if (data.nic !== "admin" && data.pass === "admin") {
      this.setState({
        unameError: "block",
        pwError: "none"
      });
      document.getElementById("form-username").style.borderColor = "#FF4545";
      document.getElementById("form-password").style.borderColor = "#17A2B8";
    } else if (data.nic === "admin" && data.pass !== "admin") {
      this.setState({
        unameError: "none",
        pwError: "block"
      });
      document.getElementById("form-username").style.borderColor = "#17A2B8";
      document.getElementById("form-password").style.borderColor = "#FF4545";
    } else if (data.nic !== "admin" || data.pass !== "admin") {
      this.setState({
        unameError: "block",
        pwError: "block"
      });
      document.getElementById("form-username").style.borderColor = "#FF4545";
      document.getElementById("form-password").style.borderColor = "#FF4545";
    }
    // })
    // .catch(error => {
    //
    //   //tempory
    //   this.setState({
    //     action: "/dashboard"
    //   });
    //   this.props.handleShow("Network Error!", "danger", "outline-danger");
    // });
  }

  render() {
    return (
      <div className="loginContainer">
        <div className="text-center loginBody">
          <form onSubmit={e => this.handleSubmit(e)} className="form-signin">
            <img
              className="mb-4"
              src="https://upload.wikimedia.org/wikipedia/en/thumb/1/1d/Sri_Lanka_Police_logo.svg/350px-Sri_Lanka_Police_logo.svg.png"
              width="125"
              height="150"
            />
            <h1 className="h3 mb-3 font-weight-normal">Please sign in</h1>
            <input
              className="form-control"
              id="form-username"
              type="text"
              name="uname"
              placeholder="Username"
              required
              autoFocus
              onChange={event => this.handleUnameInput(event)}
              value={this.state.uname}
            />
            <error
              style={{
                textAlign: "left",
                marginBottom: "10px",
                color: "#FF4545",
                display: this.state.unameError,
                fontSize: "12px"
              }}
            >
              Invalid Username
            </error>
            <input
              className="form-control"
              id="form-password"
              type="password"
              name="pass"
              placeholder="Password"
              required
              onChange={event => this.handlePwordInput(event)}
              value={this.state.pword}
            />
            <error
              style={{
                textAlign: "left",
                marginTop: "-10px",
                marginBottom: "10px",
                color: "#FF4545",
                display: this.state.pwError,
                fontSize: "12px"
              }}
            >
              Invalid Password
            </error>
            <input
              className="btn btn-lg btn-info btn-block"
              type="submit"
              value="Login"
            />
          </form>
        </div>
      </div>
    );
  }
}

export default login;
