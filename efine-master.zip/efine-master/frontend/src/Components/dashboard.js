import React, { Component } from "react";
import axios from "axios";

import Header from "./includes/header";
import Sidebar from "./includes/sidebar";

class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      regCivilians: null,
      pendingCivilians: null,
      regPoliceOfficers: null,
      pendingPoliceOfficers: null,
      eFinePapers: null,
      pendingEFinePapers: null,
      incidentsReported: null,
      pendingIncidents: null,
      expiredEFinePapers: null
    };
  }

  //getting data
  async handleGet() {
    await axios
      .get(`http://45.76.195.117:5000/api/civilian/web/count/civilians/`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        this.setState({
          regCivilians: response.data
        });
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
    await axios
      .get(`http://45.76.195.117:5000/api/civilian/web/count/civilians/pending`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        this.setState({
          pendingCivilians: response.data
        });
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
    await axios
      .get(`http://45.76.195.117:5000/api/police/web/count/policemen/`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        this.setState({
          regPoliceOfficers: response.data
        });
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
    await axios
      .get(`http://45.76.195.117:5000/api/police/web/count/policemen/pending`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        this.setState({
          pendingPoliceOfficers: response.data
        });
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
    await axios
      .get(`http://45.76.195.117:5000/api/police/web/count/efines`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        this.setState({
          eFinePapers: response.data
        });
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
    await axios
      .get(`http://45.76.195.117:5000/api/police/web/count/efines/pending`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        this.setState({
          pendingEFinePapers: response.data
        });
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
    await axios
      .get(`http://45.76.195.117:5000/api/civilian/web/count/evidence`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        this.setState({
          incidentsReported: response.data
        });
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
    await axios
      .get(`http://45.76.195.117:5000/api/civilian/web/count/evidence/pending`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        this.setState({
          pendingIncidents: response.data
        });
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
    await axios
      .get(`http://45.76.195.117:5000/api/police/web/count/efines/expired`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        this.setState({
          expiredEFinePapers: response.data
        });
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  componentWillMount() {
    this.handleGet();
  }

  render() {
    return (
      <main className="app-content">
        <Header handleShow={this.props.handleShow} handleHide={this.props.handleHide} show={this.props.show} message={this.props.message} alertVariant={this.props.alertVariant} buttonVariant={this.props.buttonVariant} alertMessageContent={this.props.alertMessageContent} nfine={this.props.nfine} />
        <Sidebar />
        <div className="app-title">
          <div>
            <h1>
              <i className="fa fa-dashboard" /> Dashboard
            </h1>
            <p>Summery</p>
          </div>
          <ul className="app-breadcrumb breadcrumb">
            <li className="breadcrumb-item">
              <i className="fa fa-home fa-lg" />
            </li>
            <li className="breadcrumb-item">
              <a href="/dashboard">Dashboard</a>
            </li>
          </ul>
        </div>
        <div className="row">
          <div className="col-md-3">
            <div className="widget-small primary coloured-icon"><i className="icon fa fa-users fa-3x"></i>
              <div className="info">
                <h4>Number of Registered Civilians</h4>
                <p><b>{this.state.regCivilians}</b></p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="widget-small primary coloured-icon"><i className="icon fa fa-users fa-3x"></i>
              <div className="info">
                <h4>Number of Pending Civilians</h4>
                <p><b>{this.state.pendingCivilians}</b></p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="widget-small primary coloured-icon"><i className="icon fa fa-users fa-3x"></i>
              <div className="info">
                <h4>Number of Registered Officers</h4>
                <p><b>{this.state.regPoliceOfficers}</b></p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="widget-small primary coloured-icon"><i className="icon fa fa-users fa-3x"></i>
              <div className="info">
                <h4>Number of Pending Officers</h4>
                <p><b>{this.state.pendingPoliceOfficers}</b></p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="widget-small primary coloured-icon"><i className="icon fa fa-book fa-3x"></i>
              <div className="info">
                <h4>Number of Paid Fine Papers</h4>
                <p><b>{this.state.eFinePapers}</b></p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="widget-small primary coloured-icon"><i className="icon fa fa-users fa-3x"></i>
              <div className="info">
                <h4>Number of Pending Fine Papers</h4>
                <p><b>{this.state.pendingEFinePapers}</b></p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="widget-small primary coloured-icon"><i className="icon fa fa-users fa-3x"></i>
              <div className="info">
                <h4>Number of Incidents Reported</h4>
                <p><b>{this.state.incidentsReported}</b></p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="widget-small primary coloured-icon"><i className="icon fa fa-users fa-3x"></i>
              <div className="info">
                <h4>Number of Pending Incidents</h4>
                <p><b>{this.state.pendingIncidents}</b></p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="widget-small primary coloured-icon"><i className="icon fa fa-users fa-3x"></i>
              <div className="info">
                <h4>Number of Expired Fine Papers</h4>
                <p><b>{this.state.expiredEFinePapers}</b></p>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-md-12">
            <div className="tile">
              <h3 className="tile-title">Monthly Fines & Crimes</h3>
              <div className="embed-responsive embed-responsive-16by9">
                <canvas className="embed-responsive-item" id="lineChartDemo" />
              </div>
            </div>
          </div>
        </div>
      </main>
    );
  }
}

export default Dashboard;
