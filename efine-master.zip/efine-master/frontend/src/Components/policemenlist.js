import React, { Component } from "react";
import axios from "axios";

import Header from "./includes/header";
import Sidebar from "./includes/sidebar";

class policemenList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      policemenList: []
    };
  }

  //getting data about policemen
  async handleGet() {
    await axios
      .get(`http://45.76.195.117:5000/api/police/web/policemenlist`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        if (response.data.length >= 1) {
          this.setState({
            policemenList: response.data
          });
        } else {
          this.props.handleShow("No data!", "warning", "outline-warning");
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  //deleting data
  async handleDelete(event) {
    await axios
      .delete(`http://45.76.195.117:5000/api/police/web/delete/${event}`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        if (response.data === true) {
          this.props.handleShow("Deleted!", "info", "outline-info");
          this.handleGet();
        } else {
          this.props.handleShow(
            "Something Went Wrong!",
            "warning",
            "outline-warning"
          );
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  componentWillMount() {
    this.handleGet();
  }

  render() {
    var rows = this.state.policemenList.map((data, i) => {
      return (
        <tr className="table-info" key={i}>
          <td>{data.fname}</td>
          <td>{data.pid}</td>
          <td>{data.nic}</td>
          <td>{data.post}</td>
          <td>
            <img
              height="100px"
              src="https://images.vexels.com/media/users/3/129616/isolated/preview/fb517f8913bd99cd48ef00facb4a67c0-businessman-avatar-silhouette-by-vexels.png"
              alt="No Image"
            />
          </td>
          <td>
            <a className="btn btn-info" href={"/policemanview/" + data.pid}>
              View
            </a>
          </td>
          <td>
            <a
              className="btn btn-danger"
              href="#"
              onClick={() => this.handleDelete(data.nic)}
            >
              Delete
            </a>
          </td>
        </tr>
      );
    });
    return (
      <main className="app-content">
        <Header
          handleShow={this.props.handleShow}
          handleHide={this.props.handleHide}
          show={this.props.show}
          message={this.props.message}
          alertVariant={this.props.alertVariant}
          buttonVariant={this.props.buttonVariant}
          alertMessageContent={this.props.alertMessageContent}
          nfine={this.props.nfine}
        />
        <Sidebar />
        <title>Police Officers</title>
        <div className="app-title">
          <div>
            <h1>
              <i className="fa fa-th-list" /> List of Police Officers
            </h1>
            <p>Both registered & Approved </p>
          </div>
          <ul className="app-breadcrumb breadcrumb side">
            <li className="breadcrumb-item">
              <i className="fa fa-home fa-lg" />
            </li>
            <li className="breadcrumb-item">Police officers</li>
            <li className="breadcrumb-item active">
              <a href="#">Police officers</a>
            </li>
          </ul>
        </div>
        <div className="row">
          <div className="col-md-12">
            <div className="tile">
              <div className="tile-body" />
              <table
                className="table table-hover table-bordered"
                id="sampleTable"
              >
                <thead>
                  <tr>
                    <th>Police Man Name</th>
                    <th>Police ID</th>
                    <th>NIC</th>
                    <th>Rank of the policeman</th>
                    <th>Photo</th>
                    <th />
                    <th />
                  </tr>
                </thead>
                <tbody>{rows}</tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    );
  }
}

export default policemenList;
