import React, { Component } from "react";
import axios from "axios";

import Header from "./includes/header";
import Sidebar from "./includes/sidebar";

class civilianView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      profile: {},
      job: "",
      phone: ""
    };
  }

  // getting data about civilians
  async handleGet() {
    await axios
      .get(
        `http://45.76.195.117:5000/api/civilian/web/civiliansearch/${this.props.location.pathname.slice(
          14
        )}`,
        {
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Content-type": "application/x-www-form-urlencoded",
            Accept: "application/json"
          }
        }
      )
      .then(response => {
        if (response.data.length >= 1) {
          this.setState({
            profile: response.data[0],
            job: response.data[0].job,
            mobile: response.data[0].mobile,
            nicf: response.data[0].nicf.slice(8),
            nicb: response.data[0].nicb.slice(8)
          });
        } else {
          this.props.handleShow("No data!", "warning", "outline-warning");
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  //updating data
  async handleUpdate(event) {
    event.preventDefault();
    await axios
      .put(
        `http://45.76.195.117:5000/api/civilian/web/civilian/update/${
          this.state.profile.nic
        }&${this.state.job}&${this.state.mobile}`,
        {
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Content-type": "application/x-www-form-urlencoded",
            Accept: "application/json"
          }
        }
      )
      .then(response => {
        if (response.data.nModified === 1) {
          this.props.handleShow("Updated!", "info", "outline-info");
          this.handleGet();
        } else if (response.data.nModified === 0) {
          this.props.handleShow("Not Updated!", "info", "outline-info");
          this.handleGet();
        } else {
          this.props.handleShow(
            "Something Went Wrong!",
            "warning",
            "outline-warning"
          );
          this.handleGet();
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  //deleting data
  async handleDelete(event) {
    await axios
      .delete(`http://45.76.195.117:5000/api/civilian/web/delete/${event}`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        if (response.data === true) {
          this.props.handleShow("Deleted!", "info", "outline-info");
          window.history.go(-2);
        } else {
          this.props.handleShow(
            "Something Went Wrong!",
            "warning",
            "outline-warning"
          );
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  componentWillMount() {
    this.handleGet();
  }

  render() {
    return (
      <main className="app-content">
        <Header
          handleShow={this.props.handleShow}
          handleHide={this.props.handleHide}
          show={this.props.show}
          message={this.props.message}
          alertVariant={this.props.alertVariant}
          buttonVariant={this.props.buttonVariant}
          alertMessageContent={this.props.alertMessageContent}
          nfine={this.props.nfine}
        />
        <Sidebar />
        <title>Police Officers</title>
        <div className="app-title">
          <div>
            <h1>
              <i className="fa fa-th-list" /> Civilian
            </h1>
            <p>Profile </p>
          </div>
          <ul className="app-breadcrumb breadcrumb side">
            <li className="breadcrumb-item">
              <i className="fa fa-home fa-lg" />
            </li>
            <li className="breadcrumb-item">Civilians</li>
            <li className="breadcrumb-item active">
              <a href="#">Profile</a>
            </li>
          </ul>
        </div>
        <div className="row">
          <div className="col-sm-2 col-md-2">
            <img
              src={
                "http://45.63.88.163:3000/" +
                this.state.nicf
              }
              alt=""
              className="img-rounded img-responsive"
              width="230"
            />
            <img
              src={
                "http://45.63.88.163:3000/" +
                this.state.nicb
              }
              alt=""
              className="img-rounded img-responsive"
              width="230"
            />
          </div>
          <form
            onSubmit={e => this.handleUpdate(e)}
            className="col-sm-7 col-md-7 offset-sm-2 offset-md-2"
          >
            <blockquote className="row">
              <i className="fas fa-signature" style={{ paddingTop: "15px" }} />
              <h1 className="col-sm-11 col-md-11">
                {this.state.profile.fname}
              </h1>
            </blockquote>
            <div>
              <div className="row">
                <i
                  className="fas fa-map-marker-alt"
                  style={{
                    paddingTop: "11px",
                    paddingRight: "20px"
                  }}
                />
                <input
                  required
                  type="text"
                  className="form-control col-sm-11 col-md-11"
                  ref="address"
                  defaultValue={this.state.profile.addr}
                  placeholder="Address"
                />
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-calendar-day"
                  style={{
                    paddingTop: "11px",
                    paddingRight: "19px"
                  }}
                />
                <input
                  required
                  type="text"
                  ref="dob"
                  id="datePicker"
                  defaultValue={this.state.profile.dob}
                  className="form-control col-sm-11 col-md-11"
                  placeholder="DOB"
                />
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-venus-mars"
                  style={{
                    paddingTop: "11px",
                    paddingRight: "15px"
                  }}
                />
                <select
                  className="form-control col-sm-11 col-md-11"
                  ref="gender"
                  value={this.state.profile.gender}
                >
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-id-card"
                  style={{
                    paddingTop: "11px",
                    paddingRight: "15px"
                  }}
                />
                <input
                  required
                  type="text"
                  className="form-control col-sm-11 col-md-11"
                  ref="id"
                  pattern="^([0-9]{9}[x|X|v|V]|[0-9]{12})$"
                  defaultValue={this.state.profile.nic}
                  placeholder="NIC"
                />
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-suitcase"
                  style={{
                    paddingTop: "11px",
                    paddingRight: "16px"
                  }}
                />
                <input
                  required
                  type="text"
                  className="form-control col-sm-11 col-md-11"
                  ref="job"
                  defaultValue={this.state.profile.job}
                  onChange={event =>
                    this.setState({
                      job: event.target.value
                    })
                  }
                  placeholder="Job"
                />
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-ring"
                  style={{
                    paddingTop: "11px",
                    paddingRight: "16px"
                  }}
                />
                <input
                  required
                  type="text"
                  className="form-control col-sm-11 col-md-11"
                  ref="married"
                  defaultValue={this.state.profile.married}
                  placeholder="Civil Status"
                />
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-mobile-alt"
                  style={{
                    paddingTop: "11px",
                    paddingRight: "21px"
                  }}
                />
                <input
                  required
                  type="text"
                  className="form-control col-sm-11 col-md-11"
                  ref="mobile"
                  pattern="^([0-9]{10})$"
                  defaultValue={this.state.profile.mobile}
                  onChange={event =>
                    this.setState({
                      mobile: event.target.value
                    })
                  }
                  placeholder="Mobile"
                />
              </div>
            </div>
            <br />
            <div className="row offset-sm-9 offset-md-9">
              <div>
                <input
                  type="submit"
                  className="btn btn-info"
                  href="#"
                  value="Update"
                />
              </div>
              <div className="offset-sm-1 offset-md-1">
                <a
                  className="btn btn-danger"
                  href="#"
                  onClick={() => this.handleDelete(this.state.profile.nic)}
                >
                  Delete
                </a>
              </div>
            </div>
          </form>
        </div>
      </main>
    );
  }
}

export default civilianView;
