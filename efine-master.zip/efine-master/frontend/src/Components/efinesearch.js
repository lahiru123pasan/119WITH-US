import React, { Component } from "react";
import axios from "axios";

import Header from "./includes/header";
import Sidebar from "./includes/sidebar";

class eFineSearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      table: "none",
      efine: {},
      eid: ""
    };
  }

  //getting data
  async handleGet(event, e) {
    e.preventDefault();
    await axios
      .get(`http://45.76.195.117:5000/api/police/web/searchefine/${event}`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        if (response.data) {
          this.setState({
            table: "block",
            efine: response.data
          });
        } else {
          this.setState({
            table: "none"
          });
          this.props.handleShow("No data!", "warning", "outline-warning");
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  render() {
    return (
      <main className="app-content">
        <Header
          handleShow={this.props.handleShow}
          handleHide={this.props.handleHide}
          show={this.props.show}
          message={this.props.message}
          alertVariant={this.props.alertVariant}
          buttonVariant={this.props.buttonVariant}
          alertMessageContent={this.props.alertMessageContent}
          nfine={this.props.nfine}
        />
        <Sidebar />
        <title>Paid E Fine paper list</title>
        <div className="app-title">
          <div>
            <h1>
              <i className="fa fa-th-list" /> E Fine Paper List
            </h1>
            <p>Search </p>
          </div>
          <ul className="app-breadcrumb breadcrumb side">
            <li className="breadcrumb-item">
              <i className="fa fa-home fa-lg" />
            </li>
            <li className="breadcrumb-item">E Fine Paper List</li>
            <li className="breadcrumb-item active">
              <a href="#">Search</a>
            </li>
          </ul>
        </div>
        <div className="row">
          <div className="col-md-12">
            <div className="tile">
              <div className="tile-body"> </div>
              <h1>Search Fines</h1>
              <div className="row" />
              <form onSubmit={e => this.handleGet(this.state.eid, e)}>
                <div className="col">
                  <input
                    className="form-control"
                    type="text"
                    placeholder="Fine paper number"
                    pattern="^([0-9]{6})$"
                    message="Please enter the 6 digit E-fine number"
                    required
                    value={this.state.eid}
                    onChange={event =>
                      this.setState({ eid: event.target.value })
                    }
                  />
                </div>
                <br />
                <div className="col">
                  <input
                    className="btn btn-info"
                    type="submit"
                    value="Search"
                  />
                </div>
              </form>
            </div>
          </div>
        </div>
        <div className="row" style={{ display: this.state.table }}>
          <div className="col-md-12">
            <div className="tile">
              <div className="tile-body" />
              <table className="table table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>Fine paper id</th>
                    <th>Policeman ID</th>
                    <th>Wrong on civilian</th>
                    <th>View</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="table-info">
                    <td>{this.state.efine.eid}</td>
                    <td>{this.state.efine.pid}</td>
                    <td>{this.state.efine.offence}</td>
                    <td>
                      <a
                        className="btn btn-info"
                        href={"efineview/" + this.state.efine.eid}
                      >
                        View
                      </a>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    );
  }
}

export default eFineSearch;
