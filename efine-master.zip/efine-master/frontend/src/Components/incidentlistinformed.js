import React, { Component } from "react";
import axios from "axios";

import Header from "./includes/header";
import Sidebar from "./includes/sidebar";

class incidentListInformed extends Component {
  constructor(props) {
    super(props);
    this.state = {
      incidents: []
    };
  }

  handleGet() {
    axios
      .get(`http://45.76.195.117:5000/api/civilian/web/incidentlist`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        if (response.data.length >= 1) {
          this.setState({
            incidents: response.data
          });
        } else {
          this.props.handleShow("No data!", "warning", "outline-warning");
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  componentWillMount() {
    this.handleGet();
  }

  render() {
    var rows = this.state.incidents.map((data, i) => {
      return (
        <tr className="table-info" key={i}>
          <td>{data._id}</td>
          <td>{data.info}</td>
          <td>
            {"Date: " +
              data.date.slice(0, 10) +
              " | Time: " +
              new Date(data.date).toString().slice(16, 24)}
          </td>
          <td>
            <a className="btn btn-info" href={"incidentview/" + data.iid}>
              View
            </a>
          </td>
          <td>
            <a className="btn btn-info" href={"incidentview/" + data.iid}>
              Edit
            </a>
          </td>
        </tr>
      );
    });
    return (
      <main className="app-content">
        <Header
          handleShow={this.props.handleShow}
          handleHide={this.props.handleHide}
          show={this.props.show}
          message={this.props.message}
          alertVariant={this.props.alertVariant}
          buttonVariant={this.props.buttonVariant}
          alertMessageContent={this.props.alertMessageContent}
          nfine={this.props.nfine}
        />
        <Sidebar />
        <title>Incident List</title>
        <div className="app-title">
          <div>
            <h1>
              <i className="fa fa-th-list" /> Incident List
            </h1>
            <p>Informed </p>
          </div>
          <ul className="app-breadcrumb breadcrumb side">
            <li className="breadcrumb-item">
              <i className="fa fa-home fa-lg" />
            </li>
            <li className="breadcrumb-item"> Incident List</li>
            <li className="breadcrumb-item active">
              <a href="#">Informed</a>
            </li>
          </ul>
        </div>
        <div className="row">
          <div className="col-md-12">
            <div className="tile">
              <div className="tile-body" />
              <table className="table table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>Incident ID</th>
                    <th>Type</th>
                    <th>Date and Time</th>
                    <th>View</th>
                    <th />
                  </tr>
                </thead>
                <tbody>{rows}</tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    );
  }
}

export default incidentListInformed;
