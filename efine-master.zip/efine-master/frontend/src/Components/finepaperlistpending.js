import React, { Component } from "react";
import axios from "axios";

import Header from "./includes/header";
import Sidebar from "./includes/sidebar";

class finePaperListPending extends Component {
  constructor(props) {
    super(props);
    this.state = {
      pendingFinePaperList: []
    };
  }

  //getting data about civilians
  async handleGet() {
    await axios
      .get(`http://45.76.195.117:5000/api/police/web/efinelistpending`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        if (response.data.length >= 1) {
          this.setState({
            pendingFinePaperList: response.data
          });
        } else {
          this.props.handleShow("No data!", "warning", "outline-warning");
          this.setState({
            pendingFinePaperList: response.data
          });
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  //approveing selected user
  async handlePaid(event) {
    await axios
      .put(`http://45.76.195.117:5000/api/police/web/efine/${event}`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        if (response.data.n === 1) {
          this.props.handleShow("Paid!", "success", "outline-success");
          this.handleGet();
        } else {
          this.props.handleShow(
            "Something Went Wrong!",
            "warning",
            "outline-warning"
          );
          this.handleGet();
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  componentWillMount() {
    this.handleGet();
  }

  render() {
    var rows = this.state.pendingFinePaperList.map((data, i) => {
      return (
        <tr className="table-info" key={i}>
          <td>{data._id}</td>
          <td>{data.pid}</td>
          <td>{data.offence.replace(/[0-9]/g, "")}</td>
          <td>{data.offence.replace(/[^\d.]/g, "").replace(".", "")}</td>
          <td>{data.date.slice(0, 10)}</td>
          <td>
            <a className="btn btn-info" href={"efineview/" + data.eid}>
              View
            </a>
          </td>
          <td>
            <a
              className="btn btn-warning"
              href="#"
              onClick={() => this.handlePaid(data.eid)}
            >
              Paid
            </a>
          </td>
        </tr>
      );
    });
    return (
      <main className="app-content">
        <Header
          handleShow={this.props.handleShow}
          handleHide={this.props.handleHide}
          show={this.props.show}
          message={this.props.message}
          alertVariant={this.props.alertVariant}
          buttonVariant={this.props.buttonVariant}
          alertMessageContent={this.props.alertMessageContent}
          nfine={this.props.nfine}
        />
        <Sidebar />
        <title>Pending E Fine paper list</title>
        <div className="app-title">
          <div>
            <h1>
              <i className="fa fa-th-list" /> E Fine Paper List
            </h1>
            <p>Pending </p>
          </div>
          <ul className="app-breadcrumb breadcrumb side">
            <li className="breadcrumb-item">
              <i className="fa fa-home fa-lg" />
            </li>
            <li className="breadcrumb-item">E Fine Paper List</li>
            <li className="breadcrumb-item active">
              <a href="#">Pending</a>
            </li>
          </ul>
        </div>
        <div className="row">
          <div className="col-md-12">
            <div className="tile">
              <div className="tile-body" />
              <table className="table table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>Fine paper id</th>
                    <th>Policeman ID</th>
                    <th>Wrong on civilian</th>
                    <th>Amount</th>
                    <th>Due Date</th>
                    <th />
                    <th />
                  </tr>
                </thead>
                <tbody>{rows}</tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    );
  }
}

export default finePaperListPending;
