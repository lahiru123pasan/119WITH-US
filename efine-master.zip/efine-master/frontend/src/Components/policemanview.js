import React, { Component } from "react";
import axios from "axios";

import Header from "./includes/header";
import Sidebar from "./includes/sidebar";

class policemanView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fname: "",
      pstation: "",
      pid: "",
      nic: "",
      post: "",
      mobile: ""
    };
  }

  //getting data about civilians
  async handleGet() {
    await axios
      .get(
        `http://45.76.195.117:5000/api/police/web/searchpolice/${this.props.location.pathname.slice(
          15
        )}`,
        {
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Content-type": "application/x-www-form-urlencoded",
            Accept: "application/json"
          }
        }
      )
      .then(response => {
        if (response.data.length >= 1) {
          this.setState({
            fname: response.data[0].fname,
            pstation: response.data[0].pstation,
            pid: response.data[0].pid,
            nic: response.data[0].nic,
            post: response.data[0].post,
            mobile: response.data[0].mobile,
            ppid: response.data[0]._id
          });
        } else {
          this.props.handleShow("No data!", "warning", "outline-warning");
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  // deleting data
  async handleDelete(event) {
    await axios
      .delete(`http://45.76.195.117:5000/api/police/web/delete/${event}`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(async response => {
        if (response.data === true) {
          await this.props.handleShow("Deleted!", "info", "outline-info");
          await window.history.go(-2);
        } else {
          await this.props.handleShow(
            "Something Went Wrong!",
            "warning",
            "outline-warning"
          );
        }
      })
      .catch(async error => {
        await this.props.handleShow(
          "Network Error!",
          "danger",
          "outline-danger"
        );
      });
  }

  // updating data
  async handleUpdate(e) {
    e.preventDefault();
    await axios
      .put(
        `http://45.76.195.117:5000/api/police/web/policeman/${this.state.pid}&${
          this.state.fname
        }&${this.state.nic}&${this.state.mobile}&${this.state.pstation}&${
          this.state.post
        }`,
        {
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Content-type": "application/x-www-form-urlencoded",
            Accept: "application/json"
          }
        }
      )
      .then(response => {
        if (response.data.nModified === 1) {
          this.props.handleShow("Updated!", "info", "outline-info");
          this.handleGet();
        } else if (response.data.nModified === 0) {
          this.props.handleShow("Not Updated!", "info", "outline-info");
          this.handleGet();
        } else {
          this.props.handleShow(
            "Something Went Wrong!",
            "warning",
            "outline-warning"
          );
          this.handleGet();
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  componentWillMount() {
    this.handleGet();
  }

  render() {
    return (
      <main className="app-content">
        <Header
          handleShow={this.props.handleShow}
          handleHide={this.props.handleHide}
          show={this.props.show}
          message={this.props.message}
          alertVariant={this.props.alertVariant}
          buttonVariant={this.props.buttonVariant}
          alertMessageContent={this.props.alertMessageContent}
          nfine={this.props.nfine}
        />
        <Sidebar />
        <title>Police Officers</title>
        <div className="app-title">
          <div>
            <h1>
              <i className="fa fa-th-list" /> Policeman
            </h1>
            <p>Profile </p>
          </div>
          <ul className="app-breadcrumb breadcrumb side">
            <li className="breadcrumb-item">
              <i className="fa fa-home fa-lg" />
            </li>
            <li className="breadcrumb-item">Policeman</li>
            <li className="breadcrumb-item active">
              <a href="#">Profile</a>
            </li>
          </ul>
        </div>
        <div className="row">
          <div className="col-sm-2 col-md-2">
            <img
              src="https://images.vexels.com/media/users/3/129616/isolated/preview/fb517f8913bd99cd48ef00facb4a67c0-businessman-avatar-silhouette-by-vexels.png"
              alt=""
              className="img-rounded img-responsive"
              width="300"
            />
          </div>
          <form
            onSubmit={e => this.handleUpdate(e)}
            className="col-sm-7 col-md-7 offset-sm-2 offset-md-2"
          >
            <blockquote className="row">
              <i
                className="fas fa-signature"
                style={{ paddingTop: "15px", paddingRight: "13px" }}
              />
              <input
                required
                type="text"
                className="form-control col-sm-11 col-md-11"
                ref="name"
                value={this.state.fname}
                placeholder="Name"
                onChange={event => this.setState({ fname: event.target.value })}
              />
            </blockquote>
            <div>
              <div className="row">
                <i
                  className="fas fa-map-marker-alt"
                  style={{ paddingTop: "11px", paddingRight: "20px" }}
                />
                <input
                  required
                  type="text"
                  className="form-control col-sm-11 col-md-11"
                  ref="pstation"
                  value={this.state.pstation}
                  placeholder="Police station"
                  onChange={event =>
                    this.setState({ pstation: event.target.value })
                  }
                />
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-calendar-day"
                  style={{ paddingTop: "11px", paddingRight: "19px" }}
                />
                <input
                  required
                  type="text"
                  className="form-control col-sm-11 col-md-11"
                  ref="pid"
                  value={this.state.pid}
                  placeholder="PID"
                  onChange={event => this.setState({ pid: event.target.value })}
                />
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-id-card"
                  style={{ paddingTop: "11px", paddingRight: "15px" }}
                />
                <input
                  required
                  type="text"
                  className="form-control col-sm-11 col-md-11"
                  ref="nic"
                  value={this.state.nic}
                  pattern="^([0-9]{9}[x|X|v|V]|[0-9]{12})$"
                  placeholder="NIC"
                  onChange={event => this.setState({ nic: event.target.value })}
                />
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-suitcase"
                  style={{ paddingTop: "11px", paddingRight: "16px" }}
                />
                <select
                  className="form-control col-sm-11 col-md-11"
                  ref="job"
                  value={this.state.post}
                  onChange={event =>
                    this.setState({ post: event.target.value })
                  }
                >
                  <option value="">Select...</option>
                  <option value="Inspector General Of Police">
                    Inspector General Of Police
                  </option>
                  <option value="Senior Deputy Inspector General Of Police">
                    Senior Deputy Inspector General Of Police
                  </option>
                  <option value="Deputy Inspector General Of Police">
                    Deputy Inspector General Of Police
                  </option>
                  <option value="Senior Superintendent Of Police">
                    Senior Superintendent Of Police
                  </option>
                  <option value="Superintendent Of Police">
                    Superintendent Of Police
                  </option>
                  <option value="Assistant Superintendent Of Police">
                    Assistant Superintendent Of Police
                  </option>
                  <option value="Chief Inspector Of Police">
                    Chief Inspector Of Police
                  </option>
                  <option value="Inspector Of Police">
                    Inspector Of Police
                  </option>
                  <option value="Sub Inspector Of Police">
                    Sub Inspector Of Police
                  </option>
                  <option value="Police Sergeant Major">
                    Police Sergeant Major
                  </option>
                  <option value="Police Sergeant Class 1Ps">
                    Police Sergeant Class 1Ps
                  </option>
                  <option value="Police Sergeant Class 2Ps">
                    Police Sergeant Class 2Ps
                  </option>
                  <option value="Police Constable Class 1Pc">
                    Police Constable Class 1Pc
                  </option>
                  <option value="Police Constable Class 2Pc">
                    Police Constable Class 2Pc
                  </option>
                  <option value="Police Constable Class 3Pc">
                    Police Constable Class 3Pc
                  </option>
                  <option value="lice Constable Class 4Pc">
                    Police Constable Class 4Pc
                  </option>
                </select>
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-mobile-alt"
                  style={{ paddingTop: "11px", paddingRight: "21px" }}
                />
                <input
                  required
                  type="text"
                  className="form-control col-sm-11 col-md-11"
                  ref="mobile"
                  value={this.state.mobile}
                  pattern="^([0-9]{10})$"
                  title="Ex: 0771234567"
                  placeholder="Mobile"
                  onChange={event =>
                    this.setState({ mobile: event.target.value })
                  }
                />
              </div>
            </div>
            <br />
            <div className="row offset-sm-9 offset-md-9">
              <div>
                <input type="submit" className="btn btn-info" value="Update" />
              </div>
              <div className="offset-sm-1 offset-md-1">
                <a
                  className="btn btn-danger"
                  href="#"
                  onClick={() => this.handleDelete(this.state.nic)}
                >
                  Delete
                </a>
              </div>
            </div>
          </form>
        </div>
      </main>
    );
  }
}

export default policemanView;
