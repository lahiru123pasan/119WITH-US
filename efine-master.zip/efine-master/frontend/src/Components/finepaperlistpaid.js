import React, { Component } from "react";
import axios from "axios";

import Header from "./includes/header";
import Sidebar from "./includes/sidebar";

const querystring = require("querystring");

class finePaperListPaid extends Component {
  constructor(props) {
    super(props);
    this.state = {
      paidFinePaperList: []
    };
  }

  //getting data about civilians
  async handleGet() {
    await axios
      .get(`http://45.76.195.117:5000/api/police/web/efinelistpaid`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(response => {
        if (response.data.length >= 1) {
          this.setState({
            paidFinePaperList: response.data
          });
        } else {
          this.props.handleShow("No data!", "warning", "outline-warning");
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  componentWillMount() {
    this.handleGet();
  }

  render() {
    var rows = this.state.paidFinePaperList.map((data, i) => {
      return (
        <tr className="table-info" key={i}>
          <td>{data._id}</td>
          <td>{data.pid}</td>
          <td>{data.offence}</td>
          <td>{data.date.slice(0, 10)}</td>
          <td>
            <a className="btn btn-info" href={"efineview/" + data.eid}>
              View
            </a>
          </td>
        </tr>
      );
    });
    return (
      <main className="app-content">
        <Header
          handleShow={this.props.handleShow}
          handleHide={this.props.handleHide}
          show={this.props.show}
          message={this.props.message}
          alertVariant={this.props.alertVariant}
          buttonVariant={this.props.buttonVariant}
          alertMessageContent={this.props.alertMessageContent}
          nfine={this.props.nfine}
        />
        <Sidebar />
        <title>Paid E Fine paper list</title>
        <div className="app-title">
          <div>
            <h1>
              <i className="fa fa-th-list" /> E Fine Paper List
            </h1>
            <p>Paid </p>
          </div>
          <ul className="app-breadcrumb breadcrumb side">
            <li className="breadcrumb-item">
              <i className="fa fa-home fa-lg" />
            </li>
            <li className="breadcrumb-item">E Fine Paper List</li>
            <li className="breadcrumb-item active">
              <a href="#">Paid</a>
            </li>
          </ul>
        </div>
        <div className="row">
          <div className="col-md-12">
            <div className="tile">
              <div className="tile-body" />
              <table className="table table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>Fine paper id</th>
                    <th>Policeman ID</th>
                    <th>Wrong on civilian</th>
                    <th>Paid Date</th>
                    <th>View</th>
                  </tr>
                </thead>
                <tbody>{rows}</tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    );
  }
}

export default finePaperListPaid;
