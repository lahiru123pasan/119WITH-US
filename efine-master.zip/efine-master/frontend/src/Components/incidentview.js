import React, { Component } from "react";
import axios from "axios";

import Header from "./includes/header";
import Sidebar from "./includes/sidebar";

class incidentView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      incident: {},
      loc: [],
      image: "",
      video: "",
      audio: "",
      date: "No Data",
      time: "No Data",
      dt: null
    };
  }

  //getting data about civilians
  async handleGet() {
    await axios
      .get(
        `http://45.76.195.117:5000/api/civilian/web/viewincident/${this.props.location.pathname.slice(
          14
        )}`,
        {
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Content-type": "application/x-www-form-urlencoded",
            Accept: "application/json"
          }
        }
      )
      .then(response => {
        if (response.data) {
          this.setState({
            incident: response.data[0],
            loc: response.data[0].location.split("&"),
            image: response.data[0].image,
            dt: response.data[0].date,
            date: response.data[0].date.slice(0, 10),
            video: response.data[0].video,
            audio: response.data[0].audio
            // time: response.data[0].date.slice(11, 19)
          });
        } else {
          this.props.handleShow("No data!", "warning", "outline-warning");
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  handleInform(location, id) {
    axios
      .post(
        `http://45.76.195.117:5000/api/civilian/web/inform/${location[0]}&${
          location[1]
        }&${id}`,
        {
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Content-type": "application/x-www-form-urlencoded",
            Accept: "application/json"
          }
        }
      )
      .then(response => {
        if (response.data) {
          this.props.handleShow("Inforemed!", "info", "outline-info");
          window.location.replace("/incidentlist");
        } else {
          this.props.handleShow(
            "Error Informing!",
            "warning",
            "outline-warning"
          );
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  async componentWillMount() {
    await this.handleGet();
    var d1 = await new Date(this.state.dt);
    await this.setState({
      time: d1.toString().slice(16, 24)
    });
  }

  render() {
    return (
      <main className="app-content">
        <Header
          handleShow={this.props.handleShow}
          handleHide={this.props.handleHide}
          show={this.props.show}
          message={this.props.message}
          alertVariant={this.props.alertVariant}
          buttonVariant={this.props.buttonVariant}
          alertMessageContent={this.props.alertMessageContent}
          nfine={this.props.nfine}
        />
        <Sidebar />
        <div id="page-wrapper">
          <div className="row">
            <div className="col-lg-12">
              <h1 className="page-header">Civilian Problem View</h1>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-12">
              <div className="tabbable-panel">
                <div className="tabbable-line">
                  <ul className="nav nav-tabs">
                    <li className="active">
                      <a href="#tab_default_1" data-toggle="tab">
                        Problem{" "}
                      </a>
                    </li>
                    <li>
                      <a href="#tab_default_2" data-toggle="tab">
                        Attachments{" "}
                      </a>
                    </li>
                    <li>
                      <a href="#tab_default_3" data-toggle="tab">
                        Location{" "}
                      </a>
                    </li>
                  </ul>
                  <div className="tab-content">
                    <div className="tab-pane active" id="tab_default_1">
                      <div className="col-sm-12 col-md-12">
                        <h2 className="sprinkle_types_title">Problem Type:</h2>
                        <ul className="sprinkle_types">
                          <li>
                            {" "}
                            Date & Time: {this.state.date} | {this.state.time}
                          </li>
                        </ul>
                        <ul className="sprinkle_types">
                          <li> NIC: {this.state.incident.nic}</li>
                        </ul>
                        <ul className="sprinkle_types">
                          <li> Info: {this.state.incident.info}</li>
                        </ul>
                        <br />
                        <div className="offset-sm-8 offset-md-8">
                          <a
                            href="#"
                            className="btn btn-lg btn-danger"
                            onClick={() =>
                              this.handleInform(
                                this.state.incident.location.split("&"),
                                this.props.location.pathname.slice(14)
                              )
                            }
                          >
                            Inform to the closest police station
                          </a>
                        </div>
                      </div>
                    </div>
                    <div className="tab-pane" id="tab_default_2">
                      <div className="col-sm-12 col-md-12 row">
                        {this.state.video !== "NOVIDEO" &&
                        this.state.video !== "" ? (
                          <div className="col-sm-4">
                            <video width="auto" controls>
                              <source
                                src={
                                  "http://45.63.88.163:3000/" +
                                  this.state.video.slice(8)
                                }
                                type="video/mp4"
                              />
                              <source
                                src={
                                  "http://45.63.88.163:3000/" +
                                  this.state.video.slice(8)
                                }
                                type="video/ogg"
                              />
                              Your browser does not support HTML5 video.
                            </video>
                          </div>
                        ) : null}
                        {this.state.audio !== "NOAUDIO" &&
                        this.state.audio !== "" ? (
                          <div className="col-sm-4">
                            <audio controls>
                              <source
                                src={
                                  "http://45.63.88.163:3000/" +
                                  this.state.audio.slice(8)
                                }
                                type="audio/ogg"
                              />
                              <source
                                src={
                                  "http://45.63.88.163:3000/" +
                                  this.state.audio.slice(8)
                                }
                                type="audio/mpeg"
                              />
                              <source
                                src={
                                  "http://45.63.88.163:3000/" +
                                  this.state.audio.slice(8)
                                }
                                type="audio/wav"
                              />
                            </audio>
                          </div>
                        ) : null}
                        {this.state.image !== "NOIMAGE" &&
                        this.state.image !== "" ? (
                          <div className="col-sm-4">
                            <img
                              src={
                                "http://45.63.88.163:3000/" +
                                this.state.image.slice(8)
                              }
                              width="auto"
                            />
                          </div>
                        ) : null}
                      </div>
                    </div>
                    <div className="tab-pane" id="tab_default_3">
                      <div className="col-sm-12 col-md-12">
                        <div className="mapouter">
                          <div className="gmap_canvas">
                            <iframe
                              width="600"
                              height="500"
                              id="gmap_canvas"
                              src={
                                "https://maps.google.com/maps/embed/v1/place?key=AIzaSyDKVa4J8eiLYsOIjJy9AltC2VEV2eklg60&q=" +
                                this.state.loc[0] +
                                "," +
                                this.state.loc[1] +
                                ";zoom=1"
                              }
                              frameBorder="0"
                              scrolling="no"
                              marginHeight="0"
                              marginWidth="0"
                            />
                            <a href="https://www.pureblack.de">pureblack.de</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    );
  }
}

export default incidentView;
