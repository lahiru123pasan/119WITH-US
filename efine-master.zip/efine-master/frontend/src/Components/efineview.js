import React, { Component } from "react";
import axios from "axios";

import Header from "./includes/header";
import Sidebar from "./includes/sidebar";

class efineView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      efine: [],
      fine: null,
      offence: null
    };
  }

  // getting data about efines
  async handleGet() {
    await axios
      .get(
        `http://45.76.195.117:5000/api/police/web/searchefine/${this.props.location.pathname.slice(
          11
        )}`,
        {
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Content-type": "application/x-www-form-urlencoded",
            Accept: "application/json"
          }
        }
      )
      .then(response => {
        if (response.data) {
          var str1 = response.data.offence
            .replace(/[^\d.]/g, "")
            .replace(".", "");
          var str2 = response.data.offence.replace(/[0-9]/g, "");
          this.setState({
            efine: response.data,
            fine: str1,
            offence: str2
          });
        } else {
          this.props.handleShow("No data!", "warning", "outline-warning");
        }
      })
      .catch(error => {
        this.props.handleShow("Network Error!", "danger", "outline-danger");
      });
  }

  componentWillMount() {
    this.handleGet();
  }

  render() {
    return (
      <main className="app-content">
        <Header
          handleShow={this.props.handleShow}
          handleHide={this.props.handleHide}
          show={this.props.show}
          message={this.props.message}
          alertVariant={this.props.alertVariant}
          buttonVariant={this.props.buttonVariant}
          alertMessageContent={this.props.alertMessageContent}
          nfine={this.props.nfine}
        />
        <Sidebar />
        <title>Police Officers</title>
        <div className="app-title">
          <div>
            <h1>
              <i className="fa fa-th-list" /> Police
            </h1>
            <p>Fine </p>
          </div>
          <ul className="app-breadcrumb breadcrumb side">
            <li className="breadcrumb-item">
              <i className="fa fa-home fa-lg" />
            </li>
            <li className="breadcrumb-item">Police</li>
            <li className="breadcrumb-item active">
              <a href="#">Fine</a>
            </li>
          </ul>
        </div>
        <div className="row">
          <div className="col-sm-10 col-md-10 offset-sm-1 offset-md-1">
            <div>
              <div className="row">
                <i
                  className="fas fa-file-invoice-dollar"
                  style={{ paddingTop: "3px", paddingRight: "6px" }}
                >
                  &nbsp;&nbsp;Fine ID:
                </i>
                <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{this.state.efine.eid}</p>
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-map-marker-alt"
                  style={{ paddingTop: "3px", paddingRight: "6px" }}
                >
                  &nbsp;&nbsp;Location:
                </i>
                <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{this.state.efine.place}</p>
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-calendar-day"
                  style={{ paddingTop: "3px", paddingRight: "6px" }}
                >
                  &nbsp;&nbsp;Date:
                </i>
                <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{this.state.efine.date}</p>
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-exclamation-triangle"
                  style={{ paddingTop: "3px", paddingRight: "15px" }}
                >
                  &nbsp;&nbsp;Offence:
                </i>
                <p>{this.state.offence}</p>
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-dollar-sign"
                  style={{ paddingTop: "3px", paddingRight: "15px" }}
                >
                  &nbsp;&nbsp;Fine:
                </i>
                <p>{this.state.fine}</p>
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-id-card"
                  style={{ paddingTop: "3px", paddingRight: "15px" }}
                >
                  &nbsp;&nbsp;NIC:
                </i>
                <p>{this.state.efine.nic}</p>
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-suitcase"
                  style={{ paddingTop: "3px", paddingRight: "16px" }}
                >
                  &nbsp;&nbsp;Court:
                </i>
                <p>{this.state.efine.court}</p>
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-ring"
                  style={{ paddingTop: "3px", paddingRight: "16px" }}
                >
                  &nbsp;&nbsp;Licence number:
                </i>
                <p>{this.state.efine.lnum}</p>
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-car-alt"
                  style={{ paddingTop: "3px", paddingRight: "21px" }}
                >
                  &nbsp;&nbsp;Vehicle number:
                </i>
                <p>{this.state.efine.vnum}</p>
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-laptop-medical"
                  style={{ paddingTop: "3px", paddingRight: "21px" }}
                >
                  &nbsp;&nbsp;Competent to driver:
                </i>
                <p>{this.state.efine.cdrive}</p>
              </div>
              <br />
              <div className="row">
                <i
                  className="fas fa-user-alt"
                  style={{ paddingTop: "3px", paddingRight: "21px" }}
                >
                  &nbsp;&nbsp;Policeman ID:
                </i>
                <p>{this.state.efine.pid}</p>
              </div>
            </div>
          </div>
        </div>
      </main>
    );
  }
}

export default efineView;
