import React, { Component } from "react";
import axios from "axios";

import Header from "./includes/header";
import Sidebar from "./includes/sidebar";

class userProfile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fname: "",
      pstation: "",
      pid: "",
      nic: "",
      post: "",
      mobile: ""
    };
  }

  componentWillMount() {
    // this.handleGet();
  }

  render() {
    return (
      <main className="app-content">
        <Header
          handleShow={this.props.handleShow}
          handleHide={this.props.handleHide}
          show={this.props.show}
          message={this.props.message}
          alertVariant={this.props.alertVariant}
          buttonVariant={this.props.buttonVariant}
          alertMessageContent={this.props.alertMessageContent}
          nfine={this.props.nfine}
        />
        <Sidebar />
        <title>User</title>
        <div className="app-title">
          <div>
            <h1>
              <i className="fa fa-th-list" /> User
            </h1>
            <p>Profile </p>
          </div>
          <ul className="app-breadcrumb breadcrumb side">
            <li className="breadcrumb-item">
              <i className="fa fa-home fa-lg" />
            </li>
            <li className="breadcrumb-item">User</li>
            <li className="breadcrumb-item active">
              <a href="#">Profile</a>
            </li>
          </ul>
        </div>
        <div className="row" style={{ textAlign: "center" }}>
          <div
            className="card"
            style={{
              width: "28rem",
              margin: "auto",
              width: "50%",
              border: "none",
              padding: "10px"
            }}
          >
            <center>
              <img
                //src = {source.to.profile.image}
                src="https://lh3.googleusercontent.com/p/AF1QipOyWFjv7_Q2I5sM8gPSxn-l9y5p1oAFdlH7mGyB=s1600-w400"
                alt=""
                className="img-rounded img-responsive"
                width="300"
              />
              <div className="card-body">
                <blockquote className="row">
                  <h1
                    style={{
                      textAlign: "center",
                      margin: "auto",
                      width: "50%"
                    }}
                  >
                    Admin
                  </h1>
                  <br />
                  </blockquote>
                  <blockquote className="row">
                  <h1
                    style={{
                      textAlign: "center",
                      margin: "auto",
                      width: "50%"
                    }}
                  >
                     Kaduwela Police Station                  </h1>

                     <br />
                     </blockquote>
                     <blockquote className="row">
                  <h1
                    style={{
                      textAlign: "center",
                      margin: "auto",
                      width: "50%"
                    }}
                  >
                     0112 415 222                  </h1>
                </blockquote>
              </div>
            </center>
          </div>
        </div>
      </main>
    );
  }
}

export default userProfile;
