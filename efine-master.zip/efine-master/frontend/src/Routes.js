import React, { Component } from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";

import CivilianList from "../src/Components/civilianlist";
import CivilianListPending from "../src/Components/civilianlistpending";
import CivilianSearch from "../src/Components/civiliansearch";
import CivilianView from "../src/Components/civilianview";
import PolicemanView from "../src/Components/policemanview";
import Dashboard from "../src/Components/dashboard";
import EFineSearch from "../src/Components/efinesearch";
import EFineView from "../src/Components/efineview";
import FinePaperListPaid from "../src/Components/finepaperlistpaid";
import FinePaperListPending from "../src/Components/finepaperlistpending";
import FinePaperListExpired from "../src/Components/finepaperlistexpired";
import IncidentList from "../src/Components/incidentlist";
import IncidentListInformed from "../src/Components/incidentlistinformed";
import IncidentView from "../src/Components/incidentview";
import Login from "../src/Components/login";
import PolicemenList from "../src/Components/policemenlist";
import PolicemenListPending from "../src/Components/policemenlistpending";
import Reports from "../src/Components/reports";
import SearchPolice from "../src/Components/searchpolice";
import UserProfile from "../src/Components/userprofile";

class Routes extends Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      message: "Some Error Occured!",
      alertVariant: "danger",
      buttonVariant: "outline-danger"
    };
  }

  handleHide = () => {
    document.querySelector("#app-header").style.marginTop = "60px";
    document.querySelector(".app-content").style.marginTop = "100px";
    document.querySelector(".app-sidebar").style.marginTop = "60px";
    document.querySelector(".app-header-message").style.marginTop = "-100px";
    this.setState({ show: false });
    setTimeout(() => {
      this.setState({ message: "Some Error Occured!" });
    }, 300);
  };

  handleShow = (msg, alertVariant, buttonVariant) => {
    this.setState({
      message: msg,
      alertVariant: alertVariant,
      buttonVariant: buttonVariant,
      show: true
    });
    document.querySelector("#app-header").style.marginTop = "126px";
    document.querySelector(".app-sidebar").style.marginTop = "126px";
    document.querySelector(".app-content").style.marginTop = "172px";
    document.querySelector(".app-header-message").style.marginTop = "-172px";
    document.querySelector(".app-header-alert").style.marginTop = "-142px";
  };

  render() {
    return (
      <Router>
        <div>
          <Route
            path="/civilianlist"
            exact
            strict
            render={props => (
              <CivilianList
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/civilianlistpending"
            exact
            strict
            render={props => (
              <CivilianListPending
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/civiliansearch"
            exact
            strict
            render={props => (
              <CivilianSearch
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/civilianview/:nic"
            exact
            strict
            render={props => (
              <CivilianView
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/dashboard"
            exact
            strict
            render={props => (
              <Dashboard
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/efinesearch"
            exact
            strict
            render={props => (
              <EFineSearch
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/efineview/:id"
            exact
            strict
            render={props => (
              <EFineView
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/finepaperlistpaid"
            exact
            strict
            render={props => (
              <FinePaperListPaid
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/finepaperlistpending"
            exact
            strict
            render={props => (
              <FinePaperListPending
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/finepaperlistexpired"
            exact
            strict
            render={props => (
              <FinePaperListExpired
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/incidentlist"
            exact
            strict
            render={props => (
              <IncidentList
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/incidentlistinformed"
            exact
            strict
            render={props => (
              <IncidentListInformed
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/incidentview/:iid"
            exact
            strict
            render={props => (
              <IncidentView
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/"
            exact
            strict
            render={props => (
              <Login
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/policemanview/:nic"
            exact
            strict
            render={props => (
              <PolicemanView
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/policemenlist"
            exact
            strict
            render={props => (
              <PolicemenList
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/policemenlistpending"
            exact
            strict
            render={props => (
              <PolicemenListPending
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/reports"
            exact
            strict
            render={props => (
              <Reports
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/searchpolice"
            exact
            strict
            render={props => (
              <SearchPolice
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
          <Route
            path="/user"
            exact
            strict
            render={props => (
              <UserProfile
                {...props}
                handleShow={this.handleShow.bind(this)}
                handleHide={this.handleHide.bind(this)}
                show={this.state.show}
                message={this.state.message}
                alertVariant={this.state.alertVariant}
                buttonVariant={this.state.buttonVariant}
              />
            )}
          />
        </div>
      </Router>
    );
  }
}

export default Routes;
