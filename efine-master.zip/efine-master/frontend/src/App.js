import React, { Component } from 'react';
import Alert from "react-bootstrap/Alert";
import axios from "axios";

import Routes from "./Routes";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      alertMessageContent: "Date",
      nfine: "Number"
    }
  }

  getContent() {
    axios.get(`http://45.76.195.117:5000/api/police/web/pendingfines`, {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-type": "application/x-www-form-urlencoded",
        Accept: "application/json"
      }
    })
      .then(response => {
        this.setState({
          alertMessageContent: response.data.date,
          nfine: response.data.nfine
        });
      })
      .catch(error => {
        // this.handleShow("Network Error!", "danger", "outline-danger");
      });
  }


  componentWillMount() {
    this.getContent();
  }

  render() {
    return (
      <div className="App">
        <Alert className="app-header-message" show={true} variant="danger">
          <Alert.Heading>{this.state.alertMessageContent}{" \| "}{this.state.nfine}</Alert.Heading>
        </Alert>
        <Routes />
      </div>
    );
  }
}

export default App;
