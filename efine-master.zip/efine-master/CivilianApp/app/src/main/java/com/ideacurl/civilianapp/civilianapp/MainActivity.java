package com.ideacurl.civilianapp.civilianapp;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button login;
    private Button register;
    private SharedPreferences mPreference;
    private SharedPreferences.Editor mEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mPreference = PreferenceManager.getDefaultSharedPreferences(this);
        mEditor = mPreference.edit();

        login = (Button) findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                openlogin();
            }
        });

        register = (Button) findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                openregister();
            }
        });
    }

    public void openlogin(){

        String fingerPrintAuth = mPreference.getString("fingergiven","default");

        if(fingerPrintAuth.equals("authenticated"))
        {
            Intent intent=new Intent(this, fignerprint.class);
            startActivity(intent);
        }
        else{
            Intent intent=new Intent(this, Login.class);
            startActivity(intent);
        }

    }

    public void openregister(){
        Intent intent=new Intent(this, Register.class);
        startActivity(intent);
    }

}
