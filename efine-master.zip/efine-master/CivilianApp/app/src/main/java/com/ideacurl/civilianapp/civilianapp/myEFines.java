package com.ideacurl.civilianapp.civilianapp;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;

public class myEFines extends AppCompatActivity {

    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_efines);

        listView = (ListView)findViewById(R.id.listView);

        //getting previous response
        Intent intent = getIntent();
        String str = intent.getStringExtra("response");
        Log.d("Response",str);

        //creating array list
        ArrayList<String> arrayList = new ArrayList<>();

        try {
            //JSONObject Jobject = new JSONObject(str);
            JSONArray jsonArray = new JSONArray(str);

            if(jsonArray != null){
                for(int i=0; i<jsonArray.length(); i++){
                   JSONObject JsonObj = jsonArray.getJSONObject(i);
                   String vnum = JsonObj.getString("vnum");
                   String offence = JsonObj.getString("offence");

                   arrayList.add("Vehicle : "+vnum);
                   arrayList.add("Offence : "+offence);
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(myEFines.this,android.R.layout.simple_list_item_1,arrayList){
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

                // Get the Item from ListView
                View view =  super.getView(position, convertView, parent);

                // Initialize a TextView for ListView each Item
                TextView tv = (TextView)view.findViewById(android.R.id.text1);

                //set the text color for text view in ArrayList
                tv.setTextColor(Color.WHITE);

                return view;
            }
        };

        listView.setAdapter(arrayAdapter);

    }
}
