package com.ideacurl.civilianapp.civilianapp;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.common.api.Api;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.Buffer;
import okio.BufferedSink;
import retrofit2.Call;
import retrofit2.Callback;

public class mainmenu extends AppCompatActivity {

    private Button c911;
    private Button c9019;
    private Button qr;
    private Button clocation;
    private Button sevidence;
    private Button finelist;
    private ImageButton helpme;
    private SharedPreferences mPreference;
    private int callPermission=1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainmenu);

        //Shared Prefernce Test
        mPreference = PreferenceManager.getDefaultSharedPreferences(mainmenu.this);
       final String value = mPreference.getString("nic","default");

        mPreference = PreferenceManager.getDefaultSharedPreferences(mainmenu.this);

        Log.d("Shared In Main :",value);

        c911 = (Button) findViewById(R.id.e119);
        c911.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(ContextCompat.checkSelfPermission(mainmenu.this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED)
                {
                    call911();
                }else{
                    requestCallpermission();
                }
            }
        });

        c9019 = (Button) findViewById(R.id.a9019);
        c9019.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(ContextCompat.checkSelfPermission(mainmenu.this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED)
                {
                    call9019();
                }else{
                    requestCallpermission();
                }
            }
        });

        qr = (Button) findViewById(R.id.viewqr);
        qr.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openqr();
            }
        });

        clocation = (Button) findViewById(R.id.sendlocation);
        clocation.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openlocation();
            }
        });

        sevidence = (Button) findViewById(R.id.supplyevidence);
        sevidence.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openevidence();
            }
        });

        finelist = (Button) findViewById(R.id.myfinelist);
        finelist.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openfinelist();
            }
        });

        helpme=(ImageButton) findViewById(R.id.helpme);
        helpme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Call<ResponseBody> call=RetrofitClient
                        .getInstance()
                        .getApi()
                        .sendsms(value);

                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, retrofit2.Response<ResponseBody> response) {
                        try{

                            String s=response.body().string();
                            Toast.makeText(mainmenu.this,s,Toast.LENGTH_LONG).show();

                        }catch (IOException e){
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {

                    }
                });

            }
        });


    }

    private void requestCallpermission(){

        if(ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.CALL_PHONE)){

            new AlertDialog.Builder(this)
                    .setTitle("Permission needed")
                    .setMessage("Call permission is needed to use this function")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(mainmenu.this,new String[] {Manifest.permission.CALL_PHONE},callPermission);
                        }
                    })
                    .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create().show();


        }else{
            ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.CALL_PHONE},callPermission);
        }


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == callPermission){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                call911();
                Toast.makeText(this,"Permission granted",Toast.LENGTH_SHORT).show();

            }else{
                Toast.makeText(this,"Permission denied",Toast.LENGTH_SHORT).show();
            }
        }
    }


    public void call911() {

        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:119" ));
        startActivity(intent);

    }

    public void call9019() {

        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:9019" ));
        startActivity(intent);

    }

    public void openqr(){
        Intent intent=new Intent(this, qrview.class);
        startActivity(intent);
    }

    public void openlocation(){
        Intent intent=new Intent(this, sendlocation.class);
        startActivity(intent);
    }

    public void openevidence(){

        Intent intent=new Intent(this, supplyevidence.class);
        startActivity(intent);
    }

    public void openfinelist(){

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient okhttp = new OkHttpClient();

                String nic_val = mPreference.getString("nic","default");
                Log.d("nic",nic_val);

                //sending url encoded form
                RequestBody rqbdy = new FormBody.Builder()
                        .add("nic",nic_val)
                        .build();

                Request request = new Request.Builder()
                        .url("http://45.76.195.117:5000/api/police/getefines/")
                        .header("Content-Type","application/x-www-form-urlencoded")
                        .post(rqbdy)
                        .build();

                //check outputs
                BufferedSink req = new Buffer();
                try{
                    request.body().writeTo(req);
                    Log.d("Request",((Buffer) req).readUtf8());
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }

                //capturing response
                try{
                    Response response = okhttp.newCall(request).execute();

                    //caputure response body
                    String res = response.body().string();


                    Intent intent=new Intent(mainmenu.this, myEFines.class);
                    intent.putExtra("response",res);
                    startActivity(intent);


                }
                catch(Exception e){
                    e.printStackTrace();
                }

            }
        });

        t.start();


       // Intent intent=new Intent(this, Myfinepaperlist.class);
        //startActivity(intent);
    }


}
