package com.ideacurl.civilianapp.civilianapp;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationManager;
import android.media.Image;
import android.net.Uri;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

/* import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder; */

import com.google.android.gms.common.api.Api;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.Buffer;
import okio.BufferedSink;

//import com.google.android.gms.location.FusedLocationProviderClient;
//import com.google.android.gms.location.LocationServices;


public class supplyevidence extends AppCompatActivity {

    //  private FusedLocationProviderClient client;
    private ImageButton image, video, audio;
    private Button submit;
    private EditText info;
    private TextView textView;
    private LocationManager locationManager;
    String lattitude,longitude;
    final Context context = this;
    ProgressDialog progress;
    String f_path;
    String f_extension;
    private SharedPreferences mPreference;
    private SharedPreferences.Editor mEditor;

    //gps tracker variables
    GPSTracker gps;
    double lt = 0;
    double lg = 0;
    String location;

    //media upload paths
    String image_path="NOIMAGE";
    String video_path="NOVIDEO";
    String audio_path="NOAUDIO";

    //checkboxes
    private CheckBox withCurrentLocation;
    private CheckBox withoutCurrentLocation;

    //response sucess check
    boolean isresponseSucess=false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supplyevidence);


        textView = (TextView) findViewById(R.id.textView);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        info = (EditText) findViewById(R.id.info);
        submit = (Button) findViewById(R.id.submit);
        image = (ImageButton) findViewById(R.id.image);
        video = (ImageButton) findViewById(R.id.video);
        audio = (ImageButton) findViewById(R.id.audio);
        withCurrentLocation = findViewById(R.id.cloc);
        withoutCurrentLocation = findViewById(R.id.wcloc);

        mPreference = PreferenceManager.getDefaultSharedPreferences(supplyevidence.this);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            image.setEnabled(false);

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
        } else {
            image.setEnabled(true);
        }


        image.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

              /*
                Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(takePicture,0); */

                // Pick picture from gallery
                //Intent pickPhoto = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                final String[] choices = {"Take a Photo", "Choose from Gallery"};
                AlertDialog.Builder builder = new AlertDialog.Builder(supplyevidence.this);
                builder.setTitle("Select a Option");
                builder.setItems(choices, new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which){

                        if("Take a Photo".equals(choices[which]))
                        {
                            // Taking picture from camera
                            Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            startActivityForResult(takePicture,0);
                        }
                        else if("Choose from Gallery".equals(choices[which])){

                            //Pick picture from gallery
                            Intent pickPhoto = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                            pickPhoto.setType("image/*");
                            startActivityForResult(pickPhoto,1);

                        }


                    }
                });
                builder.show();
            }

        });

        video.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                final String[] choices = {"Record a Video", "Choose from Gallery"};
                AlertDialog.Builder builder = new AlertDialog.Builder(supplyevidence.this);
                builder.setTitle("Select a Option");
                builder.setItems(choices, new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which){

                        if("Record a Video".equals(choices[which]))
                        {
                            // Taking video from camera
                            Intent takeVideo = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                            startActivityForResult(takeVideo,2);
                        }
                        else if("Choose from Gallery".equals(choices[which])){

                            //Pick video from gallery
                            Intent pickVideo = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
                            pickVideo.setType("video/*");
                            startActivityForResult(pickVideo,3);

                        }

                    }
                });
                builder.show();
            }
        });

        audio.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                /*Intent pickAudio = new Intent();
                pickAudio.setType("audio/*");
                pickAudio.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(pickAudio,4); */

                Intent pickAudio = new Intent(Intent.ACTION_PICK, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(pickAudio,4);

            }
        });


        /*submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ActivityCompat.checkSelfPermission(supplyevidence.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(supplyevidence.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }else{
                    Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

                    Location location1 = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

                    Location location2 = locationManager.getLastKnownLocation(LocationManager. PASSIVE_PROVIDER);

                    if (location != null) {
                        double latti = location.getLatitude();
                        double longi = location.getLongitude();
                        lattitude = String.valueOf(latti);
                        longitude = String.valueOf(longi);


                    } else  if (location1 != null) {
                        double latti = location1.getLatitude();
                        double longi = location1.getLongitude();
                        lattitude = String.valueOf(latti);
                        longitude = String.valueOf(longi);


                    } else  if (location2 != null) {
                        double latti = location2.getLatitude();
                        double longi = location2.getLongitude();
                        lattitude = String.valueOf(latti);
                        longitude = String.valueOf(longi);


                    }else{

                        Toast.makeText(supplyevidence.this,"Unable to Trace your location",Toast.LENGTH_SHORT).show();

                    }

                }
            }
        }); */

        withoutCurrentLocation.setChecked(true);

        // Check Box Listners
        withoutCurrentLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(withCurrentLocation.isChecked()){
                    withCurrentLocation.setChecked(false);
                    withoutCurrentLocation.setChecked(true);

                    lg = 0;
                    lt = 0;
                }
                else if(!withoutCurrentLocation.isChecked() && !withCurrentLocation.isChecked()){
                    withoutCurrentLocation.setChecked(true);

                    lg = 0;
                    lt = 0;
                }
            }
        });

        withCurrentLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(withoutCurrentLocation.isChecked()){
                    withoutCurrentLocation.setChecked(false);
                    withCurrentLocation.setChecked(true);

                    //getting lt and lg
                    gps = new GPSTracker(supplyevidence.this);

                    //longtitude
                    lg = gps.getLongitude();

                    //latitude
                    lt = gps.getLatitude();

                    Log.d("Longtitude : ", String.valueOf(lg));
                    Log.d("Latitude", String.valueOf(lt));
                    gps.stopUsingGPS();

                }
                else if(!withCurrentLocation.isChecked() && !withoutCurrentLocation.isChecked()){
                    withCurrentLocation.setChecked(true);
                    //getting lt and lg
                    gps = new GPSTracker(supplyevidence.this);

                    //longtitude
                    lg = gps.getLongitude();

                    //latitude
                    lt = gps.getLatitude();

                    Log.d("Longtitude : ", String.valueOf(lg));
                    Log.d("Latitude", String.valueOf(lt));
                    gps.stopUsingGPS();
                }
            }
        });

        // submit button click
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Thread t = new Thread(new Runnable() {
                    @Override
                    public void run() {

                        String nic_val = mPreference.getString("nic", "default");
                        //Log.d("NIC",nic_val);

                        location = lt + "&" + lg;

                        Log.d("LatLong", location);

                        Log.d("nic",nic_val);

                        //getting info in textbox
                        String info_v = "default";
                        info_v = String.valueOf(info.getText());
                        Log.d("info", info_v);



                        //sendind POST request
                        OkHttpClient client = new OkHttpClient();

                        //need to change NIC value to "nic_val" later
                        RequestBody request_body = new FormBody.Builder()
                                .add("nic", String.valueOf(nic_val))
                                .add("image", image_path)
                                .add("video", video_path)
                                .add("audio", audio_path)
                                .add("location", location)
                                .add("info", info_v)
                                .build();

                        //sending url encoded form
                        Request request = new Request.Builder()
                                .url("http://45.76.195.117:5000/api/civilian/addevidence")
                                .header("Content-Type", "application/x-www-form-urlencoded")
                                .post(request_body)
                                .build();

                        //request output
                        BufferedSink req = new Buffer();
                        try {
                            request.body().writeTo(req);
                            Log.d("Request", ((Buffer) req).readUtf8());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        //capture response
                        try {
                            Response response = client.newCall(request).execute();
                            String res_2 = response.body().string();
                            Log.i("response body", res_2);

                            if(response.isSuccessful()){
                                isresponseSucess = true;
                            }
                            else{
                                isresponseSucess = false;
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }


                    }
                });

                t.start();

                if(isresponseSucess){
                    Toast.makeText(supplyevidence.this,"Evidence Send Success",Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(supplyevidence.this,"Evidence Send Failed! Try again",Toast.LENGTH_LONG).show();
                }


            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent ImageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, ImageReturnedIntent);
        switch(requestCode){
            case 0:
                if(resultCode == RESULT_OK)
                {
                    // Uploading Progress

                    progress = new ProgressDialog(context);
                    progress.setTitle("Uploading");
                    progress.setMessage("Please Wait...");
                    progress.show();

                    //if user pick camera option -- IMAGE
                    Bitmap photo = (Bitmap)ImageReturnedIntent.getExtras().get("data");
                    Uri capturedImage = getImageUri(this,photo);
                    String filePath = getPath(capturedImage);
                    String fileExtn = filePath.substring(filePath.lastIndexOf(".")+1);
                    f_path = filePath;
                    f_extension = fileExtn;

                    try
                    {
                        if(fileExtn.equals("img") || fileExtn.equals("jpg") || fileExtn.equals("jpeg") || fileExtn.equals("gif") || fileExtn.equals("png")){
                            //Fine Do the Upload to server
                            Toast.makeText(this,filePath,Toast.LENGTH_SHORT).show();

                            // Upload file to server
                            Thread t = new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    // Upload file to server
                                    File f = new File(f_path);
                                    String content_type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f_extension);
                                    OkHttpClient client = new OkHttpClient();
                                    RequestBody file_body = RequestBody.create(MediaType.parse(content_type),f);
                                    Log.d("Image : " , f_path.substring(f_path.lastIndexOf("/")+1));

                                    RequestBody request_body = new MultipartBody.Builder()
                                            .setType(MultipartBody.FORM)
                                            .addFormDataPart("type",content_type)
                                            .addFormDataPart("file", f_path.substring(f_path.lastIndexOf("/")+1), file_body )
                                            .build();

                                    Request request = new Request.Builder()
                                            .url("http://45.63.88.163:3000/upload/image/AKzjTbynpg9bXQVTaSyPNkfr5snXENnXcGD6fFzwNQMNLz4MDe7H86T2tZh3TeTmMKwgVAYanaKmn9jxuspxpePvn6P898qXCcXQtd3N4p4pL39SybRAHSPFequXHP38")
                                            .post(request_body)
                                            .build();

                                    try{

                                        Response response = client.newCall(request).execute();

                                        image_path = response.body().string();

                                        Log.i("response body",image_path);

                                        if(!response.isSuccessful()){
                                            throw new Exception("Error: "+response);
                                        }

                                        progress.dismiss();

                                    }
                                    catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }
                            });
                            t.start();

                        }
                        else{
                            //NOT in request format
                            Toast.makeText(this,"Invalid Format",Toast.LENGTH_SHORT).show();
                        }
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }


                }
                break;
            case 1:
                if(resultCode == RESULT_OK)
                {
                    // Uploading Progress

                    progress = new ProgressDialog(context);
                    progress.setTitle("Uploading");
                    progress.setMessage("Please Wait...");
                    progress.show();

                    // if user pick gallery option --IMAGE
                    Uri selectedImage = ImageReturnedIntent.getData();
                    String filePath = getPath(selectedImage);
                    String fileExtn = filePath.substring(filePath.lastIndexOf(".")+1);
                    f_path = filePath;
                    f_extension = fileExtn;

                    try
                    {
                        if(fileExtn.equals("img") || fileExtn.equals("jpg") || fileExtn.equals("jpeg") || fileExtn.equals("gif") || fileExtn.equals("png")){
                            //Fine Do the Upload to server
                            Toast.makeText(this,filePath,Toast.LENGTH_SHORT).show();

                            Thread t = new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    // Upload file to server
                                    File f = new File(f_path);
                                    String content_type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f_extension);
                                    OkHttpClient client = new OkHttpClient();
                                    RequestBody file_body = RequestBody.create(MediaType.parse(content_type),f);
                                    Log.d("I am here : " , "I am here");

                                    RequestBody request_body = new MultipartBody.Builder()
                                            .setType(MultipartBody.FORM)
                                            .addFormDataPart("type",content_type)
                                            .addFormDataPart("file", f_path.substring(f_path.lastIndexOf("/")+1), file_body )
                                            .build();

                                    Request request = new Request.Builder()
                                            .url("http://45.63.88.163:3000/upload/image/AKzjTbynpg9bXQVTaSyPNkfr5snXENnXcGD6fFzwNQMNLz4MDe7H86T2tZh3TeTmMKwgVAYanaKmn9jxuspxpePvn6P898qXCcXQtd3N4p4pL39SybRAHSPFequXHP38")
                                            .post(request_body)
                                            .build();

                                    try{

                                        Response response = client.newCall(request).execute();
                                        image_path = response.body().string();
                                        Log.i("response body",image_path);

                                        if(!response.isSuccessful()){
                                            throw new Exception("Error: "+response);
                                        }

                                        progress.dismiss();

                                    }
                                    catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }
                            });
                            t.start();

                        }
                        else{
                            //NOT in request format
                        }
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
                break;
            case 2:
                if(resultCode == RESULT_OK)
                {
                    //Uploading Progeress
                    progress = new ProgressDialog(context);
                    progress.setTitle("Uploading");
                    progress.setMessage("Please Wait...");
                    progress.show();

                    //if user record a video
                    Uri selectedVideo = ImageReturnedIntent.getData();
                    String filePath = getPath(selectedVideo);
                    String fileExtn = filePath.substring(filePath.lastIndexOf(".")+1);
                    f_path = filePath;
                    f_extension = fileExtn;

                    Toast.makeText(this,filePath,Toast.LENGTH_SHORT).show();

                    // SERVER UPLOAD CODE
                    // Upload file to server
                    Thread t = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            // Upload file to server
                            File f = new File(f_path);
                            String content_type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f_extension);
                            OkHttpClient client = new OkHttpClient();
                            RequestBody file_body = RequestBody.create(MediaType.parse(content_type),f);
                            Log.d("I am here : " , "I am here");

                            RequestBody request_body = new MultipartBody.Builder()
                                    .setType(MultipartBody.FORM)
                                    .addFormDataPart("type",content_type)
                                    .addFormDataPart("file", f_path.substring(f_path.lastIndexOf("/")+1), file_body )
                                    .build();

                            Request request = new Request.Builder()
                                    .url("http://45.63.88.163:3000/upload/image/AKzjTbynpg9bXQVTaSyPNkfr5snXENnXcGD6fFzwNQMNLz4MDe7H86T2tZh3TeTmMKwgVAYanaKmn9jxuspxpePvn6P898qXCcXQtd3N4p4pL39SybRAHSPFequXHP38")
                                    .post(request_body)
                                    .build();

                            try{

                                Response response = client.newCall(request).execute();
                                video_path = response.body().string();
                                Log.i("response body",video_path);
                                if(!response.isSuccessful()){
                                    throw new Exception("Error: "+response);
                                }

                                progress.dismiss();

                            }
                            catch(Exception e){
                                e.printStackTrace();
                            }
                        }
                    });
                    t.start();
                }
                break;
            case 3:
                if(resultCode == RESULT_OK){

                    //Uploading Progress
                    progress = new ProgressDialog(context);
                    progress.setTitle("Uploading");
                    progress.setMessage("Please Wait...");
                    progress.show();

                    // if user select video from gallery
                    Uri selectedVideo = ImageReturnedIntent.getData();
                    String filePath = getPath(selectedVideo);
                    String fileExtn = filePath.substring(filePath.lastIndexOf(".") + 1);
                    f_path = filePath;
                    f_extension = fileExtn;

                    Toast.makeText(this, filePath, Toast.LENGTH_SHORT).show();

                    // SERVER UPLOAD CODE
                    // Upload file to server
                    Thread t = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            // Upload file to server
                            File f = new File(f_path);
                            String content_type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f_extension);

                            OkHttpClient client = new OkHttpClient.Builder()
                                    .connectTimeout(15, TimeUnit.SECONDS)
                                    .writeTimeout(15, TimeUnit.SECONDS)
                                    .readTimeout(30, TimeUnit.SECONDS)
                                    .build();

                            RequestBody file_body = RequestBody.create(MediaType.parse(content_type),f);
                            Log.d("I am here : " , "I am here");

                            RequestBody request_body = new MultipartBody.Builder()
                                    .setType(MultipartBody.FORM)
                                    .addFormDataPart("type",content_type)
                                    .addFormDataPart("file", f_path.substring(f_path.lastIndexOf("/")+1), file_body )
                                    .build();

                            Request request = new Request.Builder()
                                    .url("http://45.63.88.163:3000/upload/image/AKzjTbynpg9bXQVTaSyPNkfr5snXENnXcGD6fFzwNQMNLz4MDe7H86T2tZh3TeTmMKwgVAYanaKmn9jxuspxpePvn6P898qXCcXQtd3N4p4pL39SybRAHSPFequXHP38")
                                    .post(request_body)
                                    .build();



                            try{

                                Response response = client.newCall(request).execute();

                               // Log.d("Raw Response", response.body().string());

                                video_path = response.body().string();
                                Log.i("response body",video_path);

                                if(!response.isSuccessful()){
                                    throw new Exception("Error: "+response);
                                }

                                progress.dismiss();

                            }
                            catch(Exception e){
                                e.printStackTrace();
                            }
                        }
                    });
                    t.start();

                }
                break;
            case 4:
                if(resultCode==RESULT_OK)
                {
                    Log.d("Result","Result OK");

                    //upload progress
                    progress = new ProgressDialog(context);
                    progress.setTitle("Uploading");
                    progress.setMessage("Please Wait...");
                    progress.show();

                    Uri selectedAudio = ImageReturnedIntent.getData();
                    String filePath = getPath(selectedAudio);
                    String fileExtn = filePath.substring(filePath.lastIndexOf(".") + 1);

                    f_path = filePath;
                    Log.d("Audio Path", f_path);
                    f_extension = fileExtn;
                    Log.d("Audio Extension", f_extension);


                    // upload audio to server

                    Thread t = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            File f = new File(f_path);
                            String content_type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f_extension);
                            OkHttpClient client = new OkHttpClient();
                            RequestBody file_body = RequestBody.create(MediaType.parse(content_type),f);
                            Log.d("I am here : " , "I am here");

                            RequestBody request_body = new MultipartBody.Builder()
                                    .setType(MultipartBody.FORM)
                                    .addFormDataPart("type",content_type)
                                    .addFormDataPart("file", f_path.substring(f_path.lastIndexOf("/")+1), file_body )
                                    .build();

                            Request request = new Request.Builder()
                                    .url("http://45.63.88.163:3000/upload/image/AKzjTbynpg9bXQVTaSyPNkfr5snXENnXcGD6fFzwNQMNLz4MDe7H86T2tZh3TeTmMKwgVAYanaKmn9jxuspxpePvn6P898qXCcXQtd3N4p4pL39SybRAHSPFequXHP38")
                                    .post(request_body)
                                    .build();

                            try{

                                Response response = client.newCall(request).execute();
                                audio_path = response.body().string();
                                Log.i("response body",audio_path);

                                if(!response.isSuccessful()){
                                    throw new Exception("Error: "+response);
                                }

                                progress.dismiss();

                            }
                            catch(Exception e){
                                e.printStackTrace();
                            }


                        }
                    });

                    t.start();



                }
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 0) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                image.setEnabled(true);            }
        }
    }

    // Get Path of the image

    public String getPath(Uri uri){

        String[] projection = {MediaStore.MediaColumns.DATA};

        //store query result in cursor variable
        Cursor cursor = getContentResolver().query(uri,projection,null,null,null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        cursor.moveToFirst();
        String imagePath = cursor.getString(column_index);
        //Test Output
        Log.d("Image Path : " , imagePath);
        //return string
        return cursor.getString(column_index);

    }

    //Live Feed get PATH

    //function to convert Bitmap image into URI path
    public Uri getImageUri(Context inContxt, Bitmap InImage){
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        InImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContxt.getContentResolver(), InImage, "CapturedImage",null);
        return Uri.parse(path);
    }



}
