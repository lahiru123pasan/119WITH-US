package com.ideacurl.civilianapp.civilianapp;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.webkit.WebView;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

public class qrview extends Activity {

    WebView webView;

    private SharedPreferences mPreference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrview);


          mPreference = PreferenceManager.getDefaultSharedPreferences(qrview.this);

            String nic_val = mPreference.getString("nic","default");


        setContentView(R.layout.activity_qrview);
        webView = (WebView)findViewById(R.id.webv);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("http://45.76.195.117:5000/qr/"+nic_val+".svg");


    }


}
