package com.ideacurl.civilianapp.civilianapp;

import android.Manifest;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SharedMemory;
import android.preference.PreferenceManager;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.concurrent.TimeUnit;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

import okhttp3.FormBody;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.Buffer;
import okio.BufferedSink;

public class Login extends AppCompatActivity {

    private Button login;
    private Button landing;
    private String password_str;
    private String nic_str;
    private SharedPreferences mPreference;
    private SharedPreferences.Editor mEditor;
    private String fingergiven;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // defeine variables
        landing = (Button) findViewById(R.id.login);
        final EditText nic = findViewById(R.id.nic);
        final EditText pass = findViewById(R.id.pass);

        //shared preference test
        mPreference = PreferenceManager.getDefaultSharedPreferences(Login.this);
        mEditor = mPreference.edit();

        //check if user authorized fingermark
        fingergiven = mPreference.getString("fingergiven","default");


        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.USE_FINGERPRINT)!= PackageManager.PERMISSION_GRANTED){
            return;
        }



        landing.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

                if(TextUtils.isEmpty(nic.getText().toString()) && TextUtils.isEmpty(pass.getText().toString())){
                    custom_alert("Please Enter Your NIC and Password",Login.this,"Alert");
                }
                else{
                    Log.d("MSG","CLICKED");
                    nic_str = nic.getText().toString();
                    password_str = pass.getText().toString();

                    //save NIC and Password in sharedPreferences
                    mEditor.putString("nic",nic_str);
                    mEditor.commit();
                    mEditor.putString("pass",password_str);
                    mEditor.commit();

                    //Test Value
                    String value = mPreference.getString("nic","default");
                    Log.d("Prefernce Value : ",value);

                    //Intent intent=new Intent(Login.this, mainmenu.class);
                    //startActivity(intent);

                    openlanding();

                }

            }
        });


//        nic=(EditText) findViewById(R.id.nic);
//        pass=(EditText) findViewById(R.id.pass);
//
//        landing.setOnClickListener(
//                new View.OnClickListener() {
//
//                    public void onClick(View view) {
//
//                        System.out.println(nic.getText().toString());
//                        System.out.println(pass.getText().toString());
//
//                    }
//                });


    }



    public void openlanding(){

        //POST request to authenticate user
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();

                //sending url encoded form
                RequestBody request_body = new FormBody.Builder()
                        .add("nic",nic_str)
                        .add("pass", password_str )
                        .build();

                Request request = new Request.Builder()
                        .url("http://45.76.195.117:5000/api/civilian/login")
                        .header("Content-Type","application/x-www-form-urlencoded")
                        .post(request_body)
                        .build();

                BufferedSink req = new Buffer();
                try{
                    request.body().writeTo(req);
                    Log.d("Request",((Buffer) req).readUtf8());
                }
                catch(Exception e){
                    e.printStackTrace();
                }


                //capturing response
                try{

                    Response response = client.newCall(request).execute();

                    //save captured response to variable
                   // response_capture = response.body().string();
                    String res_2 = response.body().string();

                    Log.i("response body",res_2);

                    boolean isequal = res_2.equals("true");

                    if(isequal)
                    {
                        //write username to shared preferences
                        mEditor.putString("nic",nic_str);
                        mEditor.commit();

                        Log.d("Share Pref Value",mPreference.getString("fingergiven","default"));

                        if(fingergiven.equals("default"))
                        {
                            Looper.prepare();
                            AlertDialog.Builder builder1 = new AlertDialog.Builder(Login.this);
                            builder1.setTitle("Fingerprint Login");
                            builder1.setIcon(R.drawable.info);
                            builder1.setMessage("Do you want to authenticate your fingerprint for Next Login?");
                            builder1.setCancelable(false);

                            builder1.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.cancel();
                                    Intent main_menu = new Intent(Login.this,fignerprint.class);
                                    startActivity(main_menu);
                                }
                            });

                            builder1.setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.cancel();
                                    Intent main_menu = new Intent(Login.this,mainmenu.class);
                                    startActivity(main_menu);
                                }
                            });


                            AlertDialog alert1 = builder1.create();
                            alert1.show();
                            Looper.loop();
                        }
                        else{
                            Intent main_menu = new Intent(Login.this,mainmenu.class);
                            startActivity(main_menu);
                        }

                    }
                    else
                    {
                        //invalid login Alert
                        Looper.prepare();
                        AlertDialog.Builder builder1 = new AlertDialog.Builder(Login.this);
                        builder1.setTitle("Invalid Login");
                        builder1.setIcon(R.drawable.prohibition);
                        builder1.setMessage("Please type valid NIC and Password");
                        builder1.setCancelable(true);

                        builder1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        });


                        AlertDialog alert1 = builder1.create();
                        alert1.show();
                        Looper.loop();
                    }

                    if(!response.isSuccessful()){
                        throw new Exception("Error: "+response);
                    }
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }


            }
        });

        t.start();
        //new activity start
    }

    public void custom_alert(String message, Context context, String Title){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
        builder1.setTitle(Title);
        builder1.setIcon(R.drawable.info);
        builder1.setMessage(message);
        builder1.setCancelable(true);

        builder1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });


        AlertDialog alert1 = builder1.create();
        alert1.show();

    }
}
