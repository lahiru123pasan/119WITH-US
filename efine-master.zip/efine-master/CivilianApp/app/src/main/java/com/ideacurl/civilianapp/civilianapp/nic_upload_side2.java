package com.ideacurl.civilianapp.civilianapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.Buffer;
import okio.BufferedSink;

public class nic_upload_side2 extends AppCompatActivity {

    private ImageView imgView2;
    private Button CaptureBtn2;
    private SharedPreferences mPreference;
    private SharedPreferences.Editor mEditor;
    ProgressDialog progress;

    // upload path temp
    private String uplaodTmpPath = "NULL";

    String nicf = "";
    public String nicb = "";
    public String nicvalue = "NOVALUE";

    boolean isresponseSucess;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nic_upload_side2);

        //shared preferences
        mPreference = PreferenceManager.getDefaultSharedPreferences(nic_upload_side2.this);
        mEditor = mPreference.edit();

        imgView2 = (ImageView) findViewById(R.id.nicView2);
        CaptureBtn2 = (Button) findViewById(R.id.buttonUpload2);

        CaptureBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(takePicture,1);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch(requestCode){
            case 1:
                if(resultCode == RESULT_OK)
                {
                    Log.d("Result", "Result OK");
                    Bitmap photo = (Bitmap)data.getExtras().get("data");
                    imgView2.setImageBitmap(photo);

                    //getting image path
                    Uri capturedImage = getImageUri(this,photo);
                    String filePath2 = getPath(capturedImage);
                    String fileExtn = filePath2.substring(filePath2.lastIndexOf(".")+1);

                    //upload image
                    if(fileExtn.equals("img") || fileExtn.equals("jpg") || fileExtn.equals("jpeg") || fileExtn.equals("gif") || fileExtn.equals("png"))
                    {

                        String side1ImagePath = mPreference.getString("imgPathNIC","default");
                        String side1extension = mPreference.getString("imgExtnNIC", "default");
                        nicvalue = mPreference.getString("nicr","default");


                        Log.d("Side 1 Image Path : ", side1ImagePath);
                        Log.d("Side 1 Image Extn : ", side1extension);

                        Log.d("Side 2 image path : ", filePath2);
                        Log.d("Side 2 image exten : ", fileExtn);

                        progress = new ProgressDialog(nic_upload_side2.this);
                        progress.setTitle("Uploading");
                        progress.setMessage("Please Wait...");
                        progress.show();

                        upload(side1ImagePath,"http://45.63.88.163:3000/upload/image/AKzjTbynpg9bXQVTaSyPNkfr5snXENnXcGD6fFzwNQMNLz4MDe7H86T2tZh3TeTmMKwgVAYanaKmn9jxuspxpePvn6P898qXCcXQtd3N4p4pL39SybRAHSPFequXHP38",side1extension);
                        upload2(filePath2,"http://45.63.88.163:3000/upload/image/AKzjTbynpg9bXQVTaSyPNkfr5snXENnXcGD6fFzwNQMNLz4MDe7H86T2tZh3TeTmMKwgVAYanaKmn9jxuspxpePvn6P898qXCcXQtd3N4p4pL39SybRAHSPFequXHP38",fileExtn);

                        progress.dismiss();


                        Log.d("NIC", nicvalue);
                        Log.d("NIC F",nicf);

                        Thread t = new Thread(new Runnable() {
                            @Override
                            public void run() {

                                //sendind POST request
                                OkHttpClient client = new OkHttpClient();

                                //need to change NIC value to "nic_val" later
                                RequestBody request_body = new FormBody.Builder()
                                        .add("nic", nicvalue)
                                        .add("nicf", nicf)
                                        .add("nicb", nicb)
                                        .build();

                                //sending url encoded form
                                Request request = new Request.Builder()
                                        .url("http://45.76.195.117:5000/api/civilian/register/nic")
                                        .header("Content-Type", "application/x-www-form-urlencoded")
                                        .post(request_body)
                                        .build();

                                //request output
                                BufferedSink req = new Buffer();
                                try {
                                    request.body().writeTo(req);
                                    Log.d("Request", ((Buffer) req).readUtf8());
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                                //capture response
                                try {
                                    Response response = client.newCall(request).execute();
                                    String res_2 = response.body().string();
                                    Log.i("response body", res_2);

                                    if(response.isSuccessful()){
                                        isresponseSucess = true;
                                    }
                                    else{
                                        isresponseSucess = false;
                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }


                            }
                        });

                        t.start();
                        try {
                            t.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        if(isresponseSucess){
                            Intent sos = new Intent(nic_upload_side2.this,sos.class);
                            startActivity(sos);
                        }
                        else{
                            Toast.makeText(nic_upload_side2.this,"NIC Upload Failed",Toast.LENGTH_LONG).show();
                        }

                    }
                }
        }
    }

    // front side upload
    public void upload(final String imgpath, final String url, final String fileExtension)
    {

        try
        {

            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    File f = new File(imgpath);
                    String content_type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension);
                    OkHttpClient client = new OkHttpClient();
                    RequestBody file_body = RequestBody.create(MediaType.parse(content_type),f);
                    Log.d("Image : " , imgpath.substring(imgpath.lastIndexOf("/")+1));

                    RequestBody request_body = new MultipartBody.Builder()
                            .setType(MultipartBody.FORM)
                            .addFormDataPart("type",content_type)
                            .addFormDataPart("file", imgpath.substring(imgpath.lastIndexOf("/")+1), file_body )
                            .build();
                    Request request = new Request.Builder()
                            .url(url)
                            .post(request_body)
                            .build();
                    try{

                        Response response = client.newCall(request).execute();

                        String nic_path = response.body().string();
                        nicf = nic_path;

                        Log.i("response body",nicf);


                        if(!response.isSuccessful()){
                            throw new Exception("Error: "+response);
                        }


                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                }
            });
            t.start();
            t.join();

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }


    }

    // back side upload
    public void upload2(final String imgpath, final String url, final String fileExtension)
    {

        try
        {
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    File f = new File(imgpath);
                    String content_type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension);
                    OkHttpClient client = new OkHttpClient();
                    RequestBody file_body = RequestBody.create(MediaType.parse(content_type),f);
                    Log.d("Image : " , imgpath.substring(imgpath.lastIndexOf("/")+1));

                    RequestBody request_body = new MultipartBody.Builder()
                            .setType(MultipartBody.FORM)
                            .addFormDataPart("type",content_type)
                            .addFormDataPart("file", imgpath.substring(imgpath.lastIndexOf("/")+1), file_body )
                            .build();
                    Request request = new Request.Builder()
                            .url(url)
                            .post(request_body)
                            .build();
                    try{

                        Response response = client.newCall(request).execute();

                        String nic_path = response.body().string();
                        nicb = nic_path;

                        Log.i("response body",nicb);


                        if(!response.isSuccessful()){
                            throw new Exception("Error: "+response);
                        }


                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                }
            });
            t.start();
            t.join();

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }


    }

    public String getPath(Uri uri){

        String[] projection = {MediaStore.MediaColumns.DATA};

        //store query result in cursor variable
        Cursor cursor = getContentResolver().query(uri,projection,null,null,null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        cursor.moveToFirst();
        String imagePath = cursor.getString(column_index);
        //Test Output
        Log.d("Image Path : " , imagePath);
        //return string
        return cursor.getString(column_index);

    }

    //Live Feed get PATH

    //function to convert Bitmap image into URI path
    public Uri getImageUri(Context inContxt, Bitmap InImage){
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        InImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContxt.getContentResolver(), InImage, "CapturedImage",null);
        return Uri.parse(path);
    }
}
