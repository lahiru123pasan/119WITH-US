package com.ideacurl.civilianapp.civilianapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class sos extends AppCompatActivity {


    private Button save;
    private String nic;
    private EditText p1;
    private EditText p2;
    private EditText p3;
    private EditText p4;

    private String sp1;
    private String sp2;
    private String sp3;
    private String sp4;

    private SharedPreferences mPreference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sos);
        mPreference = PreferenceManager.getDefaultSharedPreferences(sos.this);
        save = (Button)findViewById(R.id.save);
        String nic_val = mPreference.getString("nicr","default");
        nic   = nic_val;
        p1=(EditText) findViewById(R.id.p1);
        p2=(EditText)findViewById(R.id.p2);
        p3=(EditText)findViewById(R.id.p3);
        p4=(EditText)findViewById(R.id.p4);

        save.setOnClickListener(
                new View.OnClickListener()
                {
                    public void onClick(View view)
                    {

                        sp1=(p1.getText().toString());
                       sp2=(p2.getText().toString());
                        sp3=(p3.getText().toString());
                        sp4=(p4.getText().toString());


                        Call<ResponseBody> call=RetrofitClient
                            .getInstance()
                            .getApi()
                            .addmobiles(nic,sp1,sp2,sp3,sp4);


                        call.enqueue(new Callback<ResponseBody>() {
                            @Override
                            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                                try{

                                    String s=response.body().string();
                                    Toast.makeText(sos.this,s,Toast.LENGTH_LONG).show();
                                    openmainactivity();
                                }catch (IOException e){
                                    System.out.println(e);
                                    e.printStackTrace();
                                }


                            }

                            @Override
                            public void onFailure(Call<ResponseBody> call, Throwable t) {
                                Toast.makeText(sos.this,t.getMessage(),Toast.LENGTH_LONG).show();
                            }
                        });

                    }
                });

    }
    public void openmainactivity(){
        Intent intent=new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}
