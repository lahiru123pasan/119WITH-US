package com.ideacurl.civilianapp.civilianapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Register extends AppCompatActivity {

    private Button btnregister;
    private EditText fname;
    private EditText nic;
    private EditText addr;
    private EditText m;
    private EditText job;
    private EditText dob;
    private RadioGroup gender;
    private RadioGroup marry;
    private RadioButton g;
    private RadioButton marr;

    String jge;
    String jmarr;

    private SharedPreferences mPreference;
    private SharedPreferences.Editor mEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //shared preference test
        mPreference = PreferenceManager.getDefaultSharedPreferences(Register.this);
        mEditor = mPreference.edit();

        gender = (RadioGroup) findViewById(R.id.radiosex);
        marry = (RadioGroup) findViewById(R.id.radiomarry);

        btnregister = (Button) findViewById(R.id.register);

        fname=(EditText) findViewById(R.id.fname);
        nic=(EditText) findViewById(R.id.nic);
        addr=(EditText) findViewById(R.id.addr);
        m=(EditText) findViewById(R.id.phone);
        job=(EditText) findViewById(R.id.job);
        dob=(EditText) findViewById(R.id.dob);


        btnregister.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

                int selectedId = gender.getCheckedRadioButtonId();

                g = (RadioButton) findViewById(selectedId);

                int mselectedId = marry.getCheckedRadioButtonId();

                marr = (RadioButton) findViewById(selectedId);

                String jfname=(fname.getText().toString());

                //nic
               final String jnic=(nic.getText().toString());

                String jaddr=(addr.getText().toString());

                //mobile
                String jm=(m.getText().toString());
                String jdob=(dob.getText().toString());
                String jjob=(job.getText().toString());


                if (selectedId == R.id.male) {
                    jge = "Male";

                } else  if (selectedId == R.id.female) {
                    jge = "Female";
                }

                 if (mselectedId == R.id.yes) {
                        jmarr = "Yes";

                    } else  if (mselectedId == R.id.no) {
                        jmarr = "No";
                    }


                Call<ResponseBody> call=RetrofitClient
                        .getInstance()
                        .getApi()
                        .register(jfname,jnic,jaddr,jm,jjob,jdob,jmarr,jge);

                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                        try{

                            String s=response.body().string();
                            Toast.makeText(Register.this,s,Toast.LENGTH_LONG).show();
                            mEditor.putString("nicr",jnic);
                            mEditor.commit();

                        }catch (IOException e){
                            e.printStackTrace();
                        }


                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Toast.makeText(Register.this,t.getMessage(),Toast.LENGTH_LONG).show();
                    }
                });


                //open NIC upload
                Intent nic_upload = new Intent(Register.this,nic_uplaod_side1.class);
                startActivity(nic_upload);


            }
        });
    }

    public void opensos(){
        Intent intent=new Intent(this, sos.class);
        startActivity(intent);
    }
}
