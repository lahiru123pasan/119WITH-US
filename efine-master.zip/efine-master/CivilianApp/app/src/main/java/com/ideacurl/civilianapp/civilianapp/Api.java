package com.ideacurl.civilianapp.civilianapp;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PartMap;

public interface Api {

    @FormUrlEncoded
    @POST("addmobiles")
    Call<ResponseBody> addmobiles(
            @Field("nic") String nic,
            @Field("p1") String p1,
            @Field("p2") String p2,
            @Field("p3") String p3,
            @Field("p4") String p4
    );


    @FormUrlEncoded
        @POST("register")
        Call<ResponseBody> register(
                @Field("fname") String fname,
                @Field("nic") String nic,
                @Field("addr") String addr,
                @Field("mobile") String mobile,
                @Field("job") String job,
                @Field("dob") String dob,
                @Field("marry") String marry,
                @Field("gender") String gender
        );

    @FormUrlEncoded
        @POST("sendsms")
        Call<ResponseBody>sendsms(
                @Field("nic") String nic
    );



//    @Multipart
//    @POST("upload")
//    Call<ResponseBody>upload(
//
//            @PartMap(String,Respo)
//
//
//
//    );


}
