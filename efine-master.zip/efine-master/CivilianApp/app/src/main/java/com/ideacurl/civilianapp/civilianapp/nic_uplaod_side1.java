package com.ideacurl.civilianapp.civilianapp;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.Console;
import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class nic_uplaod_side1 extends AppCompatActivity {

    private ImageView imgView;
    private Button CaptureBtn;
    private static final int CAMERA_REQUEST_CODE = 100;
    private SharedPreferences mPreference;
    private SharedPreferences.Editor mEditor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nic_uplaod_side1);

        // check camera permission

        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
        {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST_CODE);
        }

        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
        {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 200);
        }

        mPreference = PreferenceManager.getDefaultSharedPreferences(nic_uplaod_side1.this);
        mEditor = mPreference.edit();

        imgView = (ImageView) findViewById(R.id.nicView);
        CaptureBtn = (Button) findViewById(R.id.buttonUpload);

        CaptureBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(takePicture,0);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch(requestCode){
            case 0:
                if(resultCode == RESULT_OK)
                {
                    Log.d("Result", "Result OK");
                    Bitmap photo = (Bitmap)data.getExtras().get("data");
                    imgView.setImageBitmap(photo);

                    //getting image path
                    Uri capturedImage = getImageUri(this,photo);
                    String filePath = getPath(capturedImage);
                    String fileExtn = filePath.substring(filePath.lastIndexOf(".")+1);

                    //upload image
                    if(fileExtn.equals("img") || fileExtn.equals("jpg") || fileExtn.equals("jpeg") || fileExtn.equals("gif") || fileExtn.equals("png"))
                    {
                        mEditor.putString("imgPathNIC",filePath);
                        mEditor.commit();
                        mEditor.putString("imgExtnNIC",fileExtn);
                        mEditor.commit();

                        //sending user to next activity to upload NIC side 2

                        AlertDialog.Builder builder1 = new AlertDialog.Builder(nic_uplaod_side1.this);
                        builder1.setTitle("NIC Upload - Side 1 OK?");
                        builder1.setIcon(R.drawable.info);
                        builder1.setMessage("Upload Next side of NIC");
                        builder1.setCancelable(false);

                        builder1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                                Intent main_menu = new Intent(nic_uplaod_side1.this,nic_upload_side2.class);
                                startActivity(main_menu);
                            }
                        });

                        builder1.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();

                            }
                        });


                        AlertDialog alert1 = builder1.create();
                        alert1.show();


                    }
                }
        }
    }

    // request permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == CAMERA_REQUEST_CODE && requestCode == 200)
        {
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                CaptureBtn.setEnabled(true);
            }
            else
            {
                CaptureBtn.setEnabled(false);
            }
        }
    }



    // Get Path of the image

    public String getPath(Uri uri){

        String[] projection = {MediaStore.MediaColumns.DATA};

        //store query result in cursor variable
        Cursor cursor = getContentResolver().query(uri,projection,null,null,null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        cursor.moveToFirst();
        String imagePath = cursor.getString(column_index);
        //Test Output
        Log.d("Image Path : " , imagePath);
        //return string
        return cursor.getString(column_index);

    }

    //Live Feed get PATH

    //function to convert Bitmap image into URI path
    public Uri getImageUri(Context inContxt, Bitmap InImage){
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        InImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContxt.getContentResolver(), InImage, "CapturedImage",null);
        return Uri.parse(path);
    }

    //custom alert message
    public AlertDialog.Builder AlertBuilder(String message, Context context, String title)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title);
        builder.setIcon(R.drawable.info);
        builder.setMessage(message);
        builder.setCancelable(false);

        return builder;
    }
}
