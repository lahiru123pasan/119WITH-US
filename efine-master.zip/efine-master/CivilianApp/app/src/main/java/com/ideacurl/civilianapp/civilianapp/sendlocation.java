package com.ideacurl.civilianapp.civilianapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

//import com.google.android.gms.location.LocationListener;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Marker;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.Buffer;
import okio.BufferedSink;

public class sendlocation extends FragmentActivity implements OnMapReadyCallback {

    //variable declaration
    GoogleMap map;
    LocationManager locationManager;
    LocationListener locationListner;
    Marker marker;
    Button sendCoordinates;
    double lg=0;
    double lt=0;
    private SharedPreferences mPreference;
    private SharedPreferences.Editor mEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sendlocation);

        //getting button that send location details
        sendCoordinates = findViewById(R.id.sendloc);

        mPreference = PreferenceManager.getDefaultSharedPreferences(sendlocation.this);

        //Button Click Event
        sendCoordinates.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                GPSTracker gps = new GPSTracker(sendlocation.this);
                lt = gps.getLatitude();
                lg = gps.getLongitude();
                gps.stopUsingGPS();

                if(lg != 0 && lt != 0)
                {
                    //send API request

                    alertMessage("Data Fetched Sucess");
                    Log.d("lg",String.valueOf(lg));
                    Log.d("lg",String.valueOf(lt));

                    Thread t = new Thread(new Runnable() {
                        @Override
                        public void run() {

                            String nic_val = mPreference.getString("nic","default");
                            Log.d("NIC",nic_val);

                            //sendind POST request
                            OkHttpClient client = new OkHttpClient();

                            //need to change NIC value to "nic_val" later
                            RequestBody request_body = new FormBody.Builder()
                                    .add("lon",String.valueOf(lg))
                                    .add("lat",String.valueOf(lt))
                                    .add("nic",nic_val)
                                    .build();

                            //sending url encoded form
                            Request request = new Request.Builder()
                                    .url("http://45.76.195.117:5000/api/civilian/soscurrentlocation")
                                    .header("Content-Type","application/x-www-form-urlencoded")
                                    .post(request_body)
                                    .build();

                            //request output
                            BufferedSink req = new Buffer();
                            try{
                                request.body().writeTo(req);
                                Log.d("Request",((Buffer) req).readUtf8());
                            }
                            catch(Exception e){
                                e.printStackTrace();
                            }

                            //capture response
                            try {
                                Response response = client.newCall(request).execute();
                                String res_2 = response.body().string();
                                Log.i("response body",res_2);

                            } catch (IOException e) {
                                e.printStackTrace();
                            }


                        }
                    });

                    t.start();



                }
                else
                {
                    alertMessage("Touch the MAP to get your Current Position");
                }
            }
        });


        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mpFrgment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mpFrgment.getMapAsync(this);

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;

        GPSTracker gps = new GPSTracker(sendlocation.this);
        LatLng myLocation = new LatLng(gps.getLatitude(),gps.getLongitude());

        if(marker != null){
            marker.remove();
        }

        marker = map.addMarker(new MarkerOptions().position(myLocation).title("My Location"));
        map.moveCamera(CameraUpdateFactory.newLatLng(myLocation));
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(myLocation,14));

        //Trigger location service via LocationManager
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        locationListner = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {

                GPSTracker gps = new GPSTracker(sendlocation.this);
                LatLng myLocation = new LatLng(gps.getLatitude(),gps.getLongitude());

                if(marker != null){
                    marker.remove();
                }

                marker = map.addMarker(new MarkerOptions().position(myLocation).title("My Location"));
                map.moveCamera(CameraUpdateFactory.newLatLng(myLocation));
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(myLocation,14));

            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

                //IF GPS DISABLED DO FOLLOWING
                Intent noGps_intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(noGps_intent);

            }
        };


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.INTERNET
                }, 10);
            }
        } else {
            locationManager.requestLocationUpdates("gps", 5000, 0, locationListner);
        }

        //locationManager.requestLocationUpdates("gps", 5000, 0, locationListner); */
    }

    //Making Nessary Permissions on app
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 10:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            requestPermissions(new String[]{
                                    Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.INTERNET
                            }, 10);
                        }
                        return;
                    }
                    locationManager.requestLocationUpdates("gps", 5000, 0, locationListner);
                }
        }

    }

    public void alertMessage(String Message)
    {
        Toast.makeText(this,Message,Toast.LENGTH_SHORT).show();
    }


}
