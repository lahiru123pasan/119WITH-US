package com.ideacurl.civilianapp.civilianapp;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.fingerprint.FingerprintManager;
import android.os.CancellationSignal;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.widget.Toast;

class FingerPrintHelper extends FingerprintManager.AuthenticationCallback{

    private Context context;
    private SharedPreferences mPreference;
    private SharedPreferences.Editor mEditor;

    public FingerPrintHelper(Context context) {
        this.context = context;
    }

    public void startNewAuthenticaion(FingerprintManager fingerPrintManager, FingerprintManager.CryptoObject cryptoObject) {

        // Provides the ability to cancel an operation in progress.
        CancellationSignal cancalationalSignal = new CancellationSignal();

        //check fingerprint permission is granted
        if(ActivityCompat.checkSelfPermission(context, Manifest.permission.USE_FINGERPRINT)!= PackageManager.PERMISSION_GRANTED){
            return;
        }

        fingerPrintManager.authenticate(cryptoObject,cancalationalSignal,0,this,null);

    }

    //if authentication sucess
    @Override
    public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
        super.onAuthenticationSucceeded(result);
        Toast.makeText(context,"Finger Print Authentication Sucess", Toast.LENGTH_SHORT).show();

        //store fingerprint auth code in shared prefernces
        mPreference = PreferenceManager.getDefaultSharedPreferences(context);
        mEditor = mPreference.edit();
        mEditor.putString("fingergiven","authenticated");
        mEditor.commit();
        context.startActivity(new Intent(context,mainmenu.class));
    }

    //if authentication fails

    @Override
    public void onAuthenticationFailed() {
        super.onAuthenticationFailed();

        //if faild fingerprint
        mPreference = PreferenceManager.getDefaultSharedPreferences(context);
        mEditor = mPreference.edit();
        mEditor.putString("fingergiven","default");
        mEditor.commit();
        Toast.makeText(context,"Finger Print Authentication Faild", Toast.LENGTH_SHORT).show();
    }
}
