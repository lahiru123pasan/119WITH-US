package com.ideacurl.policeapp.policeapp;

public class Policemen {


    private String fname;
    private String nic;
    private String pid;
    private String mobile;
    private String post;
    private String pstation;
    private String status;


    public Policemen(String fname, String nic, String pid, String mobile, String post, String pstation, String status) {
        this.fname = fname;
        this.nic = nic;
        this.pid = pid;
        this.mobile = mobile;
        this.post = post;
        this.pstation = pstation;
        this.status = status;
    }

    public String getFname() {
        return fname;
    }

    public String getNic() {
        return nic;
    }

    public String getPid() {
        return pid;
    }

    public String getMobile() {
        return mobile;
    }

    public String getPost() {
        return post;
    }

    public String getPstation() {
        return pstation;
    }

    public String getStatus() {
        return status;
    }
}
