package com.ideacurl.policeapp.policeapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class editprofile extends AppCompatActivity {
    private SharedPreferences mPreference;
    private Spinner spinner;
    EditText mobile,pstation;
    Button update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editprofile);

        mPreference = PreferenceManager.getDefaultSharedPreferences(editprofile.this);
        final String pidval = mPreference.getString("pid","default");


        spinner=(Spinner)findViewById(R.id.posts);
        pstation=(EditText)findViewById(R.id.pstation);
        mobile=(EditText)findViewById(R.id.mobile);

        Spinner dropdown = findViewById(R.id.posts);

        String[] items = new String[]{
                "Inspector General Of Police",
                "Senior Deputy Inspector General Of Police",
                "Deputy Inspector General Of Police",
                "Senior Superintendent Of Police",
                "Superintendent Of Police",
                "Assistant Superintendent Of Police",
                "Chief Inspector Of Police",
                "Inspector Of Police",
                "Sub Inspector Of Police",
                "Police Sergeant Major",
                "Police Sergeant Class 1Ps",
                "Police Sergeant Class 2Ps",
                "Police Constable Class 1Pc",
                "Police Constable Class 2Pc",
                "Police Constable Class 3Pc",
                "Police Constable Class 4Pc"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);

        update=(Button) findViewById(R.id.update);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String umobile=(mobile.getText().toString());
                String upstation=(pstation.getText().toString());
                String upost=(spinner.getSelectedItem().toString());


                Call<ResponseBody> call=RetrofitClient
                        .getInstance()
                        .getApi()
                        .update(pidval,upstation,umobile,upost);

                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        try{
                            String s=response.body().string();
                            Toast.makeText(editprofile.this,s,Toast.LENGTH_LONG).show();
                            openprofile();
                        }catch (IOException e){
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {

                    }
                });
            }
        });
    }
    public void openprofile(){
        Intent intent=new Intent(this, profile.class);
        startActivity(intent);
    }
}
