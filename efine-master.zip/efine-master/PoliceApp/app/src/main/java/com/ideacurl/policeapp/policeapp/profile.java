package com.ideacurl.policeapp.policeapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class profile extends AppCompatActivity {
    private SharedPreferences mPreference;
    Button btnedit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        mPreference = PreferenceManager.getDefaultSharedPreferences(profile.this);

        final String pidval = mPreference.getString("pid","default");

        btnedit=findViewById(R.id.edit);

        btnedit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openedit();
            }
        });

        // final ListView listView=findViewById(R.id.myprofilelist);

        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(Api.baseurl)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Api api=retrofit.create(Api.class);

        Call<List<Policemen>> call=api.getPorfile(pidval);

        call.enqueue(new Callback<List<Policemen>>() {

            @Override
            public void onResponse(Call<List<Policemen>> call, Response<List<Policemen>> response) {

                List<Policemen> policemens=response.body();

                String[] policemenname=new String[policemens.size()];

//                for(int i=0;i<policemens.size();i++){
//                    policemenname[i]=policemens.get(i).getFname();
//                    policemenname[i]=policemens.get(i).getNic();
//                    policemenname[i]=policemens.get(i).getPid();
//                    policemenname[i]=policemens.get(i).getPost();
//                    policemenname[i]=policemens.get(i).getPstation();
//                    policemenname[i]=policemens.get(i).getMobile();
//
//                }

                TextView name = (TextView)findViewById(R.id.name);
                TextView nic = (TextView)findViewById(R.id.nic);
                TextView pid = (TextView)findViewById(R.id.pid);
                TextView post = (TextView)findViewById(R.id.post);
//                TextView pstation = (TextView)findViewById(R.id.pstation);
                TextView mobile = (TextView)findViewById(R.id.mobile);


                name.setText("Name: "+ policemens.get(0).getFname());
                nic.setText("NIC: "+ policemens.get(0).getNic());
                pid.setText("Police ID: "+ policemens.get(0).getPid());
                post.setText("Post: "+ policemens.get(0).getPost());
//                pstation.setText("Police Station: "+ policemens.get(0).getPstation());
                mobile.setText("Mobile: "+ policemens.get(0).getMobile());


//                listView.setAdapter(
//                        new ArrayAdapter<String>(
//                                 getApplicationContext(),
//                                android.R.layout.simple_list_item_1,
//                                policemenname
//                        )
//                );

            }

            @Override
            public void onFailure(Call<List<Policemen>> call, Throwable t) {

            }
        });
    }
    public void openedit(){
        Intent intent=new Intent(this, editprofile.class);
        startActivity(intent);
    }

}
