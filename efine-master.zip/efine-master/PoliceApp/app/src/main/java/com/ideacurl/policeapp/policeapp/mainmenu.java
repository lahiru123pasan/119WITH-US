package com.ideacurl.policeapp.policeapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class mainmenu extends AppCompatActivity {

    private Button profile;
    private Button createfine;
    private Button finelist;
    private Button capp;
    private SharedPreferences mPreference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainmenu);

        profile = (Button) findViewById(R.id.myprofile);
        profile.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                openprofile();
            }
        });

        createfine = (Button) findViewById(R.id.createfine);
        createfine.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                opencreatefine();
            }
        });

        finelist = (Button) findViewById(R.id.efinelist);
        finelist.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                openfinelist();
            }
        });

        capp=(Button) findViewById(R.id.capp);


        capp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opencivilianapp();
            }
        });
    }

    public void openprofile(){
        Intent intent=new Intent(this, profile.class);
        startActivity(intent);
    }

    public void openfinelist(){
        Intent intent=new Intent(this, efinelist.class);
        startActivity(intent);
    }

    public void opencreatefine(){
        Intent intent=new Intent(this, finescanselect.class);
        startActivity(intent);
    }

    public void opencivilianapp(){
        Intent i;
        PackageManager manager = getPackageManager();
        try {
            i = manager.getLaunchIntentForPackage("com.ideacurl.civilianapp.civilianapp");
            if (i == null)
                throw new PackageManager.NameNotFoundException();
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            startActivity(i);
        } catch (PackageManager.NameNotFoundException e) {

        }
    }
}
