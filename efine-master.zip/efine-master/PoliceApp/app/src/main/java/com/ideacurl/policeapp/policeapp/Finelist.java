package com.ideacurl.policeapp.policeapp;

public class Finelist {

    private String eid;
    private String nic;
    private String vnum;
    private String date;
    private String place;
    private String lnum;
    private String cdrive;
    private String court;
    private String offence;
    private String pid;
    private String status;

    public Finelist(String eid, String nic, String vnum, String date, String place, String lnum, String cdrive, String court, String offence, String pid, String status) {
        this.eid = eid;
        this.nic = nic;
        this.vnum = vnum;
        this.date = date;
        this.place = place;
        this.lnum = lnum;
        this.cdrive = cdrive;
        this.court = court;
        this.offence = offence;
        this.pid = pid;
        this.status = status;
    }

    public String getEid() {
        return eid;
    }

    public String getNic() {
        return nic;
    }

    public String getVnum() {
        return vnum;
    }

    public String getDate() {
        return date;
    }

    public String getPlace() {
        return place;
    }

    public String getLnum() {
        return lnum;
    }

    public String getCdrive() {
        return cdrive;
    }

    public String getCourt() {
        return court;
    }

    public String getOffence() {
        return offence;
    }

    public String getPid() {
        return pid;
    }

    public String getStatus() {
        return status;
    }
}
