package com.ideacurl.policeapp.policeapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class finescanselect extends AppCompatActivity {

    private Button qr,nic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finescanselect);


        qr=(Button) findViewById(R.id.qr);
        nic=(Button) findViewById(R.id.nic);

        qr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openqrscanner();
            }
        });

        nic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opencreateefine();
            }
        });

    }
    public void opencreateefine(){
        Intent intent=new Intent(this, createfine.class);
        startActivity(intent);
    }
    public void openqrscanner(){
            Intent intent=new Intent(this, qrreader.class);
            startActivity(intent);
    }

}
