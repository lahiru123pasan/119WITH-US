package com.ideacurl.policeapp.policeapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class createfine extends AppCompatActivity {


    private EditText nic;
    private EditText vnum;
    private EditText lnum;
    //private EditText cdrive;
    private EditText court;
    private EditText place;
    private Spinner offence;
    private Spinner cdrive;
    private Button submit;

    private SharedPreferences mPreference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createfine);

        mPreference = PreferenceManager.getDefaultSharedPreferences(createfine.this);

        final String pidval = mPreference.getString("pid","default");


        final String cnic=mPreference.getString("cnic","");

        //System.out.println(cnic);

        nic   = (EditText)findViewById(R.id.nic);
        vnum   = (EditText)findViewById(R.id.vnum);
        lnum   = (EditText)findViewById(R.id.lnum);
        court   = (EditText)findViewById(R.id.court);
//        cdrive   = (EditText)findViewById(R.id.cdrive);
        offence   = (Spinner)findViewById(R.id.offence);
        cdrive   = (Spinner)findViewById(R.id.cdrive);
        place   = (EditText) findViewById(R.id.place);
        submit=(Button)findViewById(R.id.submit);


        if(cnic != null || cnic.length() > 0){
            nic.setText(cnic);
        }


        String[] items = new String[]{
             "Idintification platet 1000",
             "Not carry R.L 1000",
             "Contravening R.L provisions 1000",
             "Driving emergency service vehicle and public service vehicle without D.L 1000",
             "Driving special purpose vehicle without a-licence 1000",
             "Not drive a license in drive a specific class 1000",
             "Not carrying D.L 1000",
             "Not having an instructor license 1000",
             "Sound or light warning 1000",
             "Not wearing protective helmet 1000",
             "Distribiution of advertisement 1000",
             "Excessive use of noice 1000",
             "Compliance with traffic signal 1000",
             "Hiring and parking 1000",
             "Not use of precautions when parking 2000",
             "Carry in passengers in extra 500"
        };

        String[] items2=new String[]{
                "Light Vehicle",
                "Heavy Vehicle",
                "Long Vehicle",
                "All Vehicle"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        offence.setAdapter(adapter);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items2);
        cdrive.setAdapter(adapter2);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                    String enic=(nic.getText().toString());
                    String elnum=(lnum.getText().toString());
                    String evnum=(vnum.getText().toString());
//                    String ecdrive=(cdrive.getText().toString());
                String ecdrive=(cdrive.getSelectedItem().toString());
                    String ecourt=(court.getText().toString());
                    String eplace=(place.getText().toString());
                    String eoffence=(offence.getSelectedItem().toString());

                    Call<ResponseBody> call=RetrofitClient
                            .getInstance()
                            .getApi()
                            .create(enic,evnum,elnum,ecdrive,ecourt,eoffence,eplace,pidval);

                    call.enqueue(new Callback<ResponseBody>() {
                        @Override
                        public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                            try{
                                String s=response.body().string();
                                Toast.makeText(createfine.this,s,Toast.LENGTH_LONG).show();
                                openmainmenu();
                            }catch (IOException e){
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onFailure(Call<ResponseBody> call, Throwable t) {

                        }
                    });

            }
        });


    }
    public void openmainmenu(){
        Intent intent=new Intent(this, mainmenu.class);
        startActivity(intent);
    }
}
