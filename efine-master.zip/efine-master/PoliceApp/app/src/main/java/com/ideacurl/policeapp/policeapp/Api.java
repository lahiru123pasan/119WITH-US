package com.ideacurl.policeapp.policeapp;

import android.content.SharedPreferences;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface Api {

   String baseurl="http://45.76.195.117:5000/api/police/";

    @GET("viewpoliceman/{pid}")
    Call<List<Policemen>>getPorfile(@Path("pid") String pid);

    @GET("web/efinelist/{pid}")
    Call<List<Finelist>>getfinelist(@Path("pid") String pid);

    @FormUrlEncoded
    @POST("register")
    Call<ResponseBody> register(
            @Field("fname") String fname,
            @Field("nic") String nic,
            @Field("pid") String pid,
            @Field("mobile") String mobile,
            @Field("pstation") String pstation,
            @Field("ppost") String ppost
    );


    @FormUrlEncoded
    @POST("efine/create")
    Call<ResponseBody> create(
            @Field("nic") String nic,
            @Field("vnum") String vnum,
            @Field("lnum") String lnum,
            @Field("cdrive") String cdrive,
            @Field("court") String court,
            @Field("offence") String offence,
            @Field("place") String place,
            @Field("pid") String pid

    );

    @FormUrlEncoded
    @POST("login")
    Call<ResponseBody> login(
            @Field("nic") String nic,
            @Field("pass") String pass
    );

    @FormUrlEncoded
    @POST("policeman/update")
    Call<ResponseBody> update(
            @Field("pid") String pid,
            @Field("pstation") String pstation,
            @Field("mobile") String mobile,
            @Field("post") String post
    );


}







