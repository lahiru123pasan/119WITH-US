package com.ideacurl.policeapp.policeapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.widget.Toast;

import com.google.android.gms.vision.barcode.Barcode;

import java.util.List;

import info.androidhive.barcode.BarcodeReader;

public class qrreader extends AppCompatActivity implements BarcodeReader.BarcodeReaderListener {


    private BarcodeReader barcodeReader;

    private SharedPreferences mPreference;
    private SharedPreferences.Editor mEditor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrreader);

        mPreference = PreferenceManager.getDefaultSharedPreferences(qrreader.this);
        mEditor = mPreference.edit();


        barcodeReader = (BarcodeReader) getSupportFragmentManager().findFragmentById(R.id.barcode_fragment);
    }

    @Override
    public void onScanned(Barcode barcode) {
        // play beep sound
        barcodeReader.playBeep();

         String bvalue=barcode.displayValue;

        System.out.println(bvalue);

        mEditor.putString("cnic",bvalue);
        mEditor.commit();

        Toast.makeText(this,barcode.displayValue,Toast.LENGTH_LONG).show();

        opencreatefine();
    }

    @Override
    public void onScannedMultiple(List<Barcode> barcodes) {

    }

    @Override
    public void onBitmapScanned(SparseArray<Barcode> sparseArray) {

    }

    @Override
    public void onScanError(String errorMessage) {

    }

    @Override
    public void onCameraPermissionDenied() {
        Toast.makeText(getApplicationContext(), "Camera permission denied!", Toast.LENGTH_LONG).show();
    }

    public void opencreatefine(){
        Intent intent=new Intent(this, createfine.class);
        startActivity(intent);
    }

}
