package com.ideacurl.policeapp.policeapp;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class efinelist extends AppCompatActivity {


    // Array of strings...
    ListView simpleList;
    private String[] lvalues;

    private SharedPreferences mPreference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_efinelist);

        mPreference = PreferenceManager.getDefaultSharedPreferences(efinelist.this);

        final String pidval = mPreference.getString("pid","default");




        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(Api.baseurl)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Api api=retrofit.create(Api.class);

        Call<List<Finelist>> call=api.getfinelist(pidval);

        call.enqueue(new Callback<List<Finelist>>() {
            @Override
            public void onResponse(Call<List<Finelist>> call, Response<List<Finelist>> response) {

                List<Finelist> finelist=response.body();

                lvalues =new String[finelist.size()];

                for (int i = 0; i < finelist.size(); i++) {

                    lvalues[i]=((finelist.get(i).getDate())+(finelist.get(i).getOffence()));
                }

                setvalues(lvalues);

            }

            @Override
            public void onFailure(Call<List<Finelist>> call, Throwable t) {

            }
        });


    }


    public void setvalues(String [] arr){

        //create object of listview
        ListView listView=(ListView)findViewById(R.id.efinelist);


        //Create Adapter
        ArrayAdapter arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,arr);

        //assign adapter to listview
        listView.setAdapter(arrayAdapter);
    }
}
