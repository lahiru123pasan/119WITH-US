package com.ideacurl.policeapp.policeapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class login extends AppCompatActivity {

    private Button mainmenu;
    private EditText nic,pass;
    private SharedPreferences mPreference;
    private SharedPreferences.Editor mEditor;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mPreference = PreferenceManager.getDefaultSharedPreferences(login.this);
        mEditor = mPreference.edit();


        nic=(EditText) findViewById(R.id.nic);
        pass=(EditText) findViewById(R.id.pass);


        mainmenu = (Button) findViewById(R.id.login);


        mainmenu.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

                final String pid=(nic.getText().toString());
                String ppass=(pass.getText().toString());


                Call<ResponseBody> call=RetrofitClient
                        .getInstance()
                        .getApi()
                        .login(pid,ppass);

                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                        try{

                            String s=response.body().string();
                            System.out.println(s);
                            if(s.equals("true")){

                                mEditor.putString("pid",pid);
                                mEditor.commit();

                                openmain();
                            }else{
                                Toast.makeText(login.this,s,Toast.LENGTH_LONG).show();
                            }

                        }catch (IOException e){
                            e.printStackTrace();
                        }


                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Toast.makeText(login.this,t.getMessage(),Toast.LENGTH_LONG).show();
                    }
                });

            }
        });



    }

    public void openmain(){
        Intent intent=new Intent(this, mainmenu.class);
        startActivity(intent);
    }

}
