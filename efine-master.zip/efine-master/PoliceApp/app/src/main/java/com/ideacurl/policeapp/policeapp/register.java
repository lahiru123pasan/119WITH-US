package com.ideacurl.policeapp.policeapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class register extends AppCompatActivity {

    private Button register;
    private EditText fname;
    private EditText nic;
    private EditText pid;
    private EditText phone;
    private EditText policestation;
    private Spinner spinner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        register = (Button)findViewById(R.id.register);
        fname   = (EditText)findViewById(R.id.fname);
        nic   = (EditText)findViewById(R.id.nic);
        pid   = (EditText)findViewById(R.id.pid);
        phone   = (EditText)findViewById(R.id.mnum);
        policestation   = (EditText)findViewById(R.id.pstation);
        spinner=(Spinner)findViewById(R.id.posts);

        Spinner dropdown = findViewById(R.id.posts);

        String[] items = new String[]{
                "Inspector General Of Police",
                "Senior Deputy Inspector General Of Police",
                "Deputy Inspector General Of Police",
                "Senior Superintendent Of Police",
                        "Superintendent Of Police",
                "Assistant Superintendent Of Police",
                "Chief Inspector Of Police",
                "Inspector Of Police",
                "Sub Inspector Of Police",
                "Police Sergeant Major",
                "Police Sergeant Class 1Ps",
                "Police Sergeant Class 2Ps",
                "Police Constable Class 1Pc",
                "Police Constable Class 2Pc",
                "Police Constable Class 3Pc",
                "Police Constable Class 4Pc"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);


        register.setOnClickListener(
                new View.OnClickListener()
                {
                    public void onClick(View view)
                    {

                        String jspinner = spinner.getSelectedItem().toString();

                        String jfname=(fname.getText().toString());
                        String jnic=(nic.getText().toString());
                        String jpid=(pid.getText().toString());
                        String jpolicestation=(policestation.getText().toString());
                        String jmobile=(phone.getText().toString());

                        Call<ResponseBody> call=RetrofitClient
                                .getInstance()
                                .getApi()
                                .register(jfname,jnic,jpid,jmobile,jpolicestation,jspinner);

                        call.enqueue(new Callback<ResponseBody>() {
                            @Override
                            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                                try{

                                    String s=response.body().string();
                                    Toast.makeText(register.this,s,Toast.LENGTH_LONG).show();
                                    openmainmenu();
                                }catch (IOException e){
                                    e.printStackTrace();
                                }

                            }

                            @Override
                            public void onFailure(Call<ResponseBody> call, Throwable t) {
                                Toast.makeText(register.this,t.getMessage(),Toast.LENGTH_LONG).show();
                            }
                        });

                    }
                });
    }

    public void openmainmenu(){
        Intent intent=new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
