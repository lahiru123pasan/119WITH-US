module.exports=(req,res,next) =>{

    const key=req.params.key;
 
    if(key===process.env.API_KEY){
        next();
    }else{
       return res.status(401).json({
            message:'Invalid key'
       });
    }
    

};