const mongo=require("mongoose");

const db=mongo.connect("mongodb://tk:L7u]T3kjckDk@45.63.88.163:27017/yunlyyt", { useNewUrlParser: true })
.then(()=> console.log("Connected"))
.catch(e=>console.log(e))

module.exports=db;