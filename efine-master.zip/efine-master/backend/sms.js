const twilio = require('twilio');

//add below credentials as environment variables when deploying

const accountSid = 'AC4c839df800de743fe6d14eeda91d5b25'; // Your Account SID from www.twilio.com/console
const authToken = 'c212d5e37b11bdddfa35e0c6b27f3a3f';   // Your Auth Token from www.twilio.com/console

var sms = new twilio(accountSid, authToken);


module.exports=sms;





