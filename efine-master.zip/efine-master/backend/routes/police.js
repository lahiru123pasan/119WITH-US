const express = require('express');
const router = express.Router();
const Joi = require('joi');
const mongo=require ("mongoose");
const cryptoRandomString = require('crypto-random-string');
const twilio=require('../sms');
const db=require('../db');
const randomstring = require("randomstring");

const policemanSchema=new mongo.Schema({
  
	fname: {type: String, required: true},
	nic: {type: String, required: true, $exists : false},
	pid: {type: String, required: true, $exists : false},
	mobile: {
		type: String,
		validate: {
			validator: function(v){
				return v.length>=10;
			},
			message: 'Mobile number must contain 10 digits'
		}
	},
	post:  {type: String, required: true},
	pstation:  {type: String, required: true},
	password:  {type: String, required: true},
	status: {type: Boolean, required: true}


});

const efineSchema=new mongo.Schema({

	eid:{type: String, required: true},
	nic: {type: String, required: true},
	vnum: {type: String, required: true},
	date:{type: String, required: true},
	place: {type: String, required: true},
	lnum: {type: String, required: true},
	cdrive:  {type: String, required: true},
	court: {type: String, required: true},
	offence: {type: String, required: true},
	pid: {type: String, required: true},
	status: {type: String, required: true}

});

const users=new mongo.Schema({

	uname:  {type: String, required: true, $exists : false},
	pass:  {type: String, required: true}

});

const Policeman=mongo.model('Policeman', policemanSchema);
const Efine=mongo.model('Efine', efineSchema);
const Users=mongo.model('Users', users);


async function viewPolicemen(){

	const policemen=await Policeman
	.find()


	   return (policemen);

}


async function viewPoliceman(pnic){

	const policeman=await Policeman
	.find({pid: pnic})

	   return (policeman);

}


async function register(pfname,pnic,ppid,pphone,ppstation,ppost){

	
		var response=[];
		const p=cryptoRandomString(5);
					const policeman=await Policeman
					.find({ nic: pnic});

					if((policeman.length)===0){
						const policeman=new Policeman({
							fname: pfname,
							nic: pnic,
							pid: ppid,
							mobile: pphone,
							post: ppost,
							pstation:ppstation,
							password: p,
							status: false
					});

							const result=await policeman.save(); 
							response.push("Added");

					}else{
						response.push("Error");
					}

			// )
			// .catch(err => reject(err));
		return response;

	// });
}


async function createefine(nic,vnum,lnum,cdrive,court,offence,place,pid){

	var response=[];

	const geid=(randomstring.generate({
		length: 5,
		charset: 'numeric'
	  }));

	const policeman=await Policeman
	.find({pid: pid})
	
	const tdate=efinegetdate();
	
	
	if(policeman.length===1){
		
		const efine=new Efine({
			eid:geid,
			nic: nic,
			vnum: vnum,
			date:tdate,
			place: place,
			lnum:lnum,
			cdrive: cdrive,
			court: court,
			offence: offence,
			pid: pid,
			status: "unpaid"

	});

			const result=await efine.save(); 
			console.log(result);
			
			response.push("Added");
	}else{
		response.push("error");
	}
					

					
		return response;

}

router.get('/policemen/',(req,res) =>{

	const object=viewPolicemen();

	object
	.then(resp => res.send(resp))
	.catch(e=>res.send(e));

});

router.post('/policeman/update',async (req,res)=>{

	const pid=req.body.pid;
	const pstation=req.body.pstation;
	const mobile=req.body.mobile;
	const post=req.body.post;

	const policeman=await Policeman.updateOne({pid: pid},{
		$set:{
			pstation:pstation,
			mobile:mobile,
			post:post
		}
	});

	res.send("Updated");

});


router.get('/viewpoliceman/:pid',(req,res) =>{
	const nic=req.params.pid;
	const object=viewPoliceman(nic);

	object
	.then(resp => res.send(resp))
	.catch(e=>res.send(e));

});

	
router.post('/register',(req,res) =>{

	const fname=req.body.fname;
	const mobile=req.body.mobile;
	const nic=req.body.nic;
	const pid=req.body.pid;
	const ppost=req.body.ppost; 
	const pstation=req.body.pstation;
	
	const object=register(fname,nic,pid,mobile,pstation,ppost);

	object
	.then(resp => res.send(resp))
	.catch(e=>res.send(e));
	
});


router.post('/efine/create', (req,res)=>{

	const nic=req.body.nic;
	const vnum=req.body.vnum;
	const lnum=req.body.lnum;
	const cdrive =req.body.cdrive;
	const court=req.body.court;
	const offence=req.body.offence;
	const place=req.body.place;
	const pid=req.body.pid;
	
	const object=createefine(nic,vnum,lnum,cdrive,court,offence,place,pid);

	object
	.then(resp => res.send(resp))
	.catch(e=>res.send(e));

});

router.post('/login', (req,res)=>{

    const pid=req.body.nic;
    const pass=req.body.pass;
    
    const object=login(pid,pass);
	object
	.then(resp=>res.send(resp))
	.catch(e=>console.log(e));
});

async function login(ppid,pass){

    const policeman=await Policeman
    .findOne({pid: ppid});    

	if(policeman===null){
		return("Invalid user!");
	}else{
		const password=policeman.password;
		
		if(password===pass){
			return(true);
		}else{
			return(false);
		}
	}

}

router.post('/getefines', async(req,res)=>{

	const pnic=req.body.nic;

    const efine=await Efine
	.find({nic: pnic}); 
	
	res.send(efine);


})


//Web
function sendSMS(number,value) {
  
    return new Promise((resolve, reject) => {
       
                twilio.messages.create({
                    body: value + ' is your Police App password.',
                    to: `+94${number}`,  // Text this number
                    from: '+14404843729' // From a valid Twilio number
                })
                    .then((message) => resolve(message.sid))
                    .catch(e=>reject(e));
            }
        
        )

}

router.get('/efine/unpaid', async (req,res)=>{

	const efine=await Efine
	.find({status:"unpaid"});

	res.send(efine);

});

router.get('/efine/paid', async (req,res)=>{

	const efine=await Efine
	.find({status:"paid"});

	res.send(efine);

});

router.put('/web/efine/:reid', async (req,res)=>{

	const reid=req.params.reid;

	const efine=await Efine.updateOne({eid: reid},{
		$set:{
			status: "paid"
		}
	});


	res.send(efine);


});

async function policepass(pnic){

	const policeman=await Policeman
	.find({nic: pnic})
	.select(password)

	   return (policeman);

}

async function viewPolicemen(){

	const policemen=await Policeman
	.find({status:true});

	   return (policemen);

}

async function viewPolicemenPending(){
	
	const policemen=await Policeman
	.find({status:false})

	   return (policemen);

}

async function approve(nnic){

	const policeman=await Policeman
	.find({nic: nnic})
	.select('password mobile');

	const m=policeman[0].mobile;
	const pass=policeman[0].password;
	
	if(policeman.length===1){

			const policeman=await Policeman.updateOne({nic: nnic},{
				$set:{
					status: true
				}
			});
			const object=sendSMS(m,pass);
			object
			.catch(e=>console.log(e));
	
			return "Approved";

	}else{
		return "User does not exsist";
	}

}

router.get('/web/policemenlist', (req,res)=>{

	const object=viewPolicemen();

	object
	.then(resp =>{
		
		res.send(resp);
		}
	)
	.catch(e=>console.log(e));

}); 
router.get('/web/efinelistpending',async (req,res)=>{
    const efine=await Efine
	.find({status:"unpaid"})

	res.send(efine);
});

router.get('/web/efinelistpaid', async (req,res)=>{
	const efine=await Efine
	.find({status:"paid"})

	res.send(efine);
});


router.get('/web/policemenlistpending', (req,res)=>{

	const object=viewPolicemenPending();

	object
	.then(resp =>{
		
		res.send(resp);
		}
	)
	.catch(e=>console.log(e));
});

router.post('/web/approve/:nic',(req,res)=>{

	const nic=req.params.nic;

	const object=approve(nic);

	object
	.then(resp =>{
		
		res.send(resp);
		}
	)
	.catch(e=>console.log(e));
});

router.delete('/web/delete/:nic', (req,res)=>{

    const nnic=req.params.nic;

    Policeman.deleteOne({nic:nnic})
    .exec()
    .then(result=>{
        res.send(true);
    })
    .catch(e=>res.send(false));

});

router.delete('/web/efinelist/delete/:reid', (req,res)=>{

    const reid=req.params.reid;

    Efine.deleteOne({eid:reid})
    .exec()
    .then(result=>{
        res.send(true);
    })
    .catch(e=>res.send(false));

});


router.get('/web/searchpolice/:nic', (req,res)=>{
   
	const nic=req.params.nic;

	const object=viewPoliceman(nic);
	object
	.then(resp=>res.send(resp))
	.catch(e=>console.log(e));

});

router.get('/web/searchefine/:eid', async (req,res)=>{
   
	const eeid=req.params.eid;
	
	const efine=await Efine
	.findOne({eid:eeid})

	res.send(efine);

});

router.get('/web/efinelist/:pid',async (req,res)=>{

	const pid=req.params.pid;

	const efine=await Efine
	.find({pid:pid})

	res.send(efine);



});

router.get('/web/count/policemen', async (req,res)=>{

	const policeman=await Policeman
	.count({status:true})

	const c=policeman.toString();

	res.send(c); 

});

router.get('/web/count/policemen/pending', async (req,res)=>{


	const policeman=await Policeman
	.count({status:false})

	const c=policeman.toString();

	res.send(c); 

});

router.get('/web/count/efines', async (req,res)=>{


	const efine=await Efine
	.count({status:true})

	const c=efine.toString();

	res.send(c); 

});

router.get('/web/count/efines', async (req,res)=>{

	const efine=await Efine
	.count({status:"paid"})

	const c=efine.toString();

	res.send(c); 

});

router.get('/web/count/efines/pending', async (req,res)=>{

	const efine=await Efine
	.count({status:"notpaid"})

	const c=efine.toString();

	res.send(c); 

});

router.get('/web/count/efines/expired', async (req,res)=>{

	const efine=await Efine
	.count({status:"expired"})

	const c=efine.toString();

	res.send(c); 

});

router.get('/web/pendingfines', async (req,res)=>{
	

	const efine=await Efine
	.find({date:getdate()})

	const le=efine.length;

	var count=0;

	for (let index = 0; index < le; index++) {
		
		// console.log(efine[index].status);

		if(efine[index].status==="unpaid"){
			count++;
		}
		
	}
	

	res.send({
		"nfine":count.toString(),
		"date":getdate()
	}
		
		);

});

router.put('/web/policeman/:pid&:pfname&:pnic&:pphone&:ppstation&:ppost',async (req,res)=>{

		const rpid=req.params.pid;
		const pfname=req.params.pfname;
		const pnic=req.params.pnic;
		const pphone=req.params.pphone;
		const ppstation=req.params.ppstation;
		const ppost=req.params.ppost;


	const policeman=await Policeman.updateOne({pid: rpid},{
		$set:{
			fname: pfname,
							nic: pnic,
							mobile: pphone,
							pstation:ppstation,
							post: ppost
		}
	});

	res.send(policeman);


});

router.get('/web/efine/expired',async (req,res)=>{

	const efine=await Efine
	.find()

	const year = new Date().getFullYear();
	const month = (new Date().getMonth())+1;
	const date = new Date().getDate();

	const today=parseInt(`${year}${month}${date}`);

	var arr=[];

	for (let index = 0; index < efine.length; index++) {

		var d=parseInt((efine[index].date).replace(/-/g,""));	

		var reid=efine[index].eid;

		if(today>d)
		{
			arr.push(efine[index]);
			updateefine(reid);
			
			
		}else{
			console.log("no");

		}

	}

	res.send(arr);


})

async function updateefine(id){

	const efine=await Efine.updateOne({eid: id},{
		$set:{
			status: "expired"
		}
	});

}

function getdate(){

	const year = new Date().getFullYear();
	const month = (new Date().getMonth())+1;
	const date = new Date().getDate();

	return `${year}-${month}-${date}`;

}
function efinegetdate(){

	const year = new Date().getFullYear();
	const month = (new Date().getMonth())+1;
	const date = new Date(Date.now() + 12096e5);

	return `${year}-${month}-${date}`;

}

module.exports=router;
