const express = require('express');
const router = express.Router();
const Joi = require('joi');
const mongo=require ("mongoose");
const db=require('../db');
const twilio=require('../sms');
const multer=require('multer');
const qr = require('qr-image');
const fs=require('fs');
const cryptoRandomString = require('crypto-random-string');
const randomstring = require("randomstring");
var svg2img = require('svg2img');
const storage=multer.diskStorage({

    destination:function(req,file,cb){
        cb(null,'./uploads/');
    },
    filename: function(req,file,cb){
        cb(null,file.originalname);   
    }

});

const fileFilter=(req,file,cb)=>{
    //reject a file
    if(file.mimetype=== 'image/jpeg' || file.mimetype=== 'image/png'  || file.mimetype=== 'image/png'){
        cb(null,true);
    }else{
        cb(null,false);
    }
}

const uploads=multer({storage:storage,limits:{
    fileSize:1024*1024*5
},fileFilter:fileFilter});

const civilianSchema=new mongo.Schema({
  
    fname: {type: String, required: true},
    nic: {type: String, required: true, $exists : false},
    addr: {type: String, required: true},
    mobile: {
        type: String,
        validate: {
            validator: function(v){
                return v.length>=10;
            },
            message: 'Mobile number must contain 10 digits'
        },
        required: true
    },
    job:  {type: String, required: true},
    dob:  {type: String, required: true},
    married:  {type: String, required: true},
    gender:  {type: String, required: true},
    password:  {type: String, required: true},
    nicf:  {type: String, required: true},
    nicb:  {type: String, required: true},
    status:  {type: Boolean, required: true}

});

const Civilian=mongo.model('Civilian', civilianSchema);

const civiliansos=new mongo.Schema({
  
    nic: {type: String, required: true, $exists : false},
    mobile1: {
        type: String,
        validate: {
            validator: function(v){
                return v.length>=10;
            },
            message: 'Mobile number must contain 10 digits'
        }
    },
    mobile2: {
        type: String,
        validate: {
            validator: function(v){
                return v.length>=10;
            },
            message: 'Mobile number must contain 10 digits'
        }
    },
    mobile3: {
        type: String,
        validate: {
            validator: function(v){
                return v.length>=10;
            },
            message: 'Mobile number must contain 10 digits'
        }
    },
    mobile4: {
        type: String,
        validate: {
            validator: function(v){
                return v.length>=10;
            },
            message: 'Mobile number must contain 10 digits'
        }
    },
  


});

const Civiliansos=mongo.model('Civiliansos', civiliansos);

const civilianevidence=new mongo.Schema({
  
    iid: { type: String , required: true},
    nic: {type: String, required: true},
    image: {type: String, required: true},
    video: {type: String, required: true},
    audio: {type: String, required: true},
    location: {type: String, required: true},
    info: {type: String, required: true},
    date:{type: Date, default: Date.now, required: true},
    status: {type: Boolean, required: true}

});
const emergency=new mongo.Schema({
  
    nic: { type: String , required: true},
    nic: {type: String, required: true},
    image: {type: String, required: true},
    video: {type: String, required: true},
    audio: {type: String, required: true},
    location: {type: String, required: true},
    info: {type: String, required: true},
    date:{type: Date, default: Date.now, required: true},
    status: {type: Boolean, required: true}

});

const Civilianevidence=mongo.model('Civilianevidence', civilianevidence);


async function addevidence(anic,aimage,avideo,aaudio,alocation,ainfo){
    
    
    var response=[];
   
    const geid=(randomstring.generate({
		length: 10,
		charset: 'numeric'
	  }));
      console.log("here");

        const civilianevidence=new Civilianevidence({
            iid:geid,
            nic: anic,
            image:aimage,
            video: avideo,
            audio: aaudio,
            location: alocation,
            info:ainfo,
            status:false
        });

            const result=await civilianevidence.save(); 
            
            response.push(result);

    return response;

}


async function register(rfname,rnic,raddr,rmobile,rjob,rdob,rmarry,rgender){
   
    
    var response=[];

     
            const p=cryptoRandomString(5);
               
                    const civilian=await Civilian
                    .find({ nic: rnic});

                    if((civilian.length)===0){
                        const civilian=new Civilian({
                            fname: rfname,
                            nic: rnic,
                            addr: raddr,
                            mobile: rmobile,
                            job: rjob,
                            dob: rdob,
                            married:rmarry,
                            gender: rgender,
                            password: p,
                            nicf: "pending",
                            nicb: "pending",
                            status:"false"
                    });

                            const result=await civilian.save(); 
                            response.push("Added");

                    }else{
                        response.push("User exsist");
                        
                    }
                

            // )
            // .catch(err => reject(err));
                    return response;
            
}

// .then(resp =>console.log(resp))

router.post('/register',(req,res) =>{
    
    const fname=req.body.fname;
    
    const nic=req.body.nic;
    const addr=req.body.addr;
    const mobile=req.body.mobile;
    const job=req.body.job;
    const dob=req.body.dob;
    const marry=req.body.marry;
    const gender=req.body.gender;

    const object=register(fname,nic,addr,mobile,job,dob,marry,gender);

    object
    .then(resp => res.send(resp))
    .catch(e=>res.send(e));
    
});

router.post('/register/nic',(req,res)=>{

    const nicf=req.body.nicf;
    const nic=req.body.nic;
    const nicb=req.body.nicb;

    const object=nicimage(nic,nicf,nicb);

    object
    .then(resp => res.send(resp))
    .catch(e=>res.send(e));

})

async function nicimage(nnic,nicf,nicb){

    const civilian=await Civilian
    .find({nic: nnic})

    if(civilian.length===1){

		const civilian=await Civilian.updateOne({nic: nnic},{
            $set:{
                   nicf: nicf,
                   nicb: nicb
               }
           });

           return "nic updated";
    }
    else{
		return "User does not exsist";
	}
}

router.post('/addevidence',(req,res)=>{

    const nic=req.body.nic;
    const image=req.body.image;
    const video=req.body.video;
    const audio=req.body.audio;
    const location=req.body.location;
    const info=req.body.info;
    
    const object=addevidence(nic,image,video,audio,location,info);

    object
    .then(resp => res.send(resp))
    .catch(e=>res.send(e));

});

router.post('/addmobiles',(req,res) =>{

    const nic=req.body.nic;
    const p1=req.body.p1;
    const p2=req.body.p2;
    const p3=req.body.p3;
    const p4=req.body.p4;

    const object=saveSOS(nic,p1,p2,p3,p4);

    object
    .then(resp => res.send(resp))
    .catch(e=>res.send(e));
    
});

// router.post('/upload', uploads.single('file'),(req,res)=>{
//     console.log(req.file);
    
// });

 async function saveSOS(nic,p1,p2,p3,p4){

    var response=[];
    const civiliansos=await Civiliansos
    .find({ nic: nic});

    if((civiliansos.length)===0){
        const civiliansos=new Civiliansos({
            nic: nic,
            mobile1: p1,
            mobile2: p2,
            mobile3: p3,
            mobile4: p4,
    });

            const result=await civiliansos.save(); 
          response.push("Added");

    }else{
       response.push("Data exsist");
        
    }

    return response;
    
}

router.post('/soscurrentlocation',(req,res)=>{

    const lon=req.body.lon;
    const lat=req.body.lat;
    const nic=req.body.nic;
    
    const object=sossendlocsms(nic,lon,lat);

    object
    .then(resp => res.send(resp))
    .catch(e=>res.send(e));

});

router.post('/sendsms',(req,res)=>{

    const nic=req.body.nic;

    const object=sossendsms(nic);

    object
    .then(resp => res.send(resp))
    .catch(e=>res.send(e));

})

function sossendlocsms(nic,lat,lon) {
  
    return new Promise((resolve, reject) => {
       
       const nums=getnumbers(nic);

        nums
        .then(resp=>{

            // const m1=resp[0].mobile1;
            // const m2=resp[0].mobile2;
            // const m3=resp[0].mobile3;
            // const m4=resp[0].mobile4;

            // const marr=[m1,m2,m3,m4];
            // console.log();
            

            // for (let index = 0; index < 4; index++) {
            //     twilio.messages.create({
            //         body: `https://www.google.com/maps/search/?api=1&query=${lon},${lat}, "HELP ME!`,
            //         to: `+94${marr[index]}`,  // Text this number
            //         from: '+14404843729' // From a valid Twilio number
            //     })
            //         .then((message) => resolve("Submitted"))
            //         .catch(e=>reject(e));
            // }
            
        }
        );

     
    }
        )

}
function sossendsms(nic) {
  
    return new Promise((resolve, reject) => {
       
       const nums=getnumbers(nic);

        nums
        .then(resp=>{

            const m1=resp[0].mobile1;
            const m2=resp[0].mobile2;
            const m3=resp[0].mobile3;
            const m4=resp[0].mobile4;

            const marr=[m1,m2,m3,m4];
            

            for (let index = 0; index < 4; index++) {
                twilio.messages.create({
                    body:  `"HELP ME!`,
                    to: `+94${marr[index]}`,  // Text this number
                    from: '+14404843729' // From a valid Twilio number
                })
                    // .then((message) => resolve(message.sid))
                    .then((message) => resolve("Sent"))
                    .catch(e=>reject(e));
            }
            
        }
        );

     
    }
        )

}
async function getnumbers(nic){

    const civiliansos=await Civiliansos
    .find({ nic: nic});

    return(civiliansos);

}

router.post('/login', (req,res)=>{

    const nic=req.body.nic;
    const pass=req.body.pass;
    
    const object=login(nic,pass);
	object
	.then(resp=>res.send(resp))
	.catch(e=>console.log(e));
});

async function login(nic,pass){

    const civilian=await Civilian
    .findOne({nic: nic});    
    
    if(civilian===null){
        return("Invalid user!");
    }else{
        if(civilian.status!=true){
            return "User has not been approved!";
        }else{
            const password=civilian.password;

            if(password===pass){
                return(true);
            }else{
                return(false);
            }
        }

      
    }

}





//web
function sendSMS(number,value) {
  
    return new Promise((resolve, reject) => {
       
                twilio.messages.create({
                    body: value + ' is your Civilian App password.',
                    to: `+94${number}`,  // Text this number
                    from: '+14404843729' // From a valid Twilio number
                })
                    .then((message) => resolve(message.sid))
                    .catch(e=>reject(e));
            }
        
        )

}

async function viewCivilians(){
	
	const civilian=await Civilian
	.find({status:true})

	   return (civilian);

}
async function viewCivilian(nic){
	
    
	const civilian=await Civilian
	.find({nic:nic})

	   return (civilian);

}
async function viewCiviliansPending(){
	
	const civilian=await Civilian
	.find({status:false})

	   return (civilian);

}

async function viewIncidents(){

    const civilianevidence=await Civilianevidence
	.find({status:true})

	   return (civilianevidence);

}
async function viewIncidentspending(){

    const civilianevidence=await Civilianevidence
	.find({status:false})

	return (civilianevidence);

}

async function viewIncident(id){

    const civilianevidence=await Civilianevidence
	.find({iid:id})

	   return (civilianevidence);

}

async function approve(nnic){

    const civilian=await Civilian
	.find({nic: nnic})
	.select('password mobile');

	const m=civilian[0].mobile;
	const pass=civilian[0].password;

    
    
	if(civilian.length===1){

		const civilian=await Civilian.updateOne({nic: nnic},{
            $set:{
                   status: true
               }
           });
			const object=sendSMS(m,pass);
            object
            .then(e=>console.log(e))
			.catch(e=>console.log(e));
            
            var qr_svg = qr.image(nnic, { type: 'svg' });
            qr_svg.pipe(fs.createWriteStream(`public/qr/${nnic}.svg`));
            
            var svg_string = qr.imageSync(nnic, { type: 'svg' });

            // svg2img(`http://45.63.88.163:3000/qr/${nnic}.svg`, {'width':800, 'height':600}, function(error, buffer) {
            // fs.writeFileSync(`public/qr/${nnic}.png`, buffer);
            // });


			return "Approved";

	}else{
		return "User does not exsist";
	}


}


router.get('/web/incidentlist', (req,res)=>{


    const object=viewIncidents();

	object
	.then(resp =>{
        res.send(resp);
		}
	)
	.catch(e=>console.log(e));

});

router.get('/web/incidentlistpending', (req,res)=>{

    const object=viewIncidentspending();

	object
	.then(resp =>{
        res.send(resp);
		}
	)
	.catch(e=>console.log(e));

});

router.get('/web/viewincident/:id', (req,res)=>{

    const id=req.params.id;

    const object=viewIncident(id);

	object
	.then(resp =>{
        
        res.send(resp);
	}
	)
	.catch(e=>console.log(e));

});

router.get('/web/incidentlistinformed', (req,res)=>{
        const object=viewIncidents();

	object
	.then(resp =>{
        res.send(resp);
		}
	)
	.catch(e=>console.log(e));
});

router.get('/web/civilianlistpending', (req,res)=>{
    
    const object=viewCiviliansPending();

	object
	.then(resp =>{
		
        res.send(resp);
		}
	)
	.catch(e=>console.log(e));

});
router.get('/web/civilianlist', (req,res)=>{

    const object=viewCivilians();

	object
	.then(resp =>{
		
		 res.send(resp);
		}
	)
	.catch(e=>console.log(e));

});

router.post('/web/approve/:nic',(req,res)=>{

	const nic=req.params.nic;

	const object=approve(nic);

	object
	.then(resp =>{
		
        res.send(resp);
		}
	)
	.catch(e=>console.log(e));
});

router.delete('/web/delete/:nic', (req,res)=>{

    const nnic=req.params.nic;

    Civilian.deleteOne({nic:nnic})
    .exec()
    .then(result=>{
        res.send(true);
    })
    .catch(e=>res.send(false));

});

router.get('/web/civiliansearch/:nic', (req,res)=>{
    const nic=req.params.nic;
    
	const object=viewCivilian(nic);
	object
	.then(resp=>res.send(resp))
	.catch(e=>console.log(e));
});


router.get('/web/count/civilians', async (req,res)=>{

	const civlilian=await Civilian
	.count({status:true})

	const c=civlilian.toString();

	res.send(c); 

});

router.get('/web/count/civilians/pending', async (req,res)=>{

	const civlilian=await Civilian
	.count({status:false})

	const c=civlilian.toString();

	res.send(c); 

});

router.get('/web/count/evidence', async (req,res)=>{

	const civilianevidence=await Civilianevidence
	.count({status:true})

	const c=civilianevidence.toString();

	res.send(c); 

});

router.get('/web/count/evidence/pending', async (req,res)=>{

	const civilianevidence=await Civilianevidence
	.count({status:false})

	const c=civilianevidence.toString();

	res.send(c); 

});

router.post('/web/inform/:lat&:lon&:id',(req,res)=>{

    const id=req.params.id;
    const lat=req.params.lat;
    const lon=req.params.lon;
    
    const object=sendlocSMS(lat,lon,id);
	object
	.then(resp=>res.send(resp))
	.catch(e=>console.log(e));

})

function sendlocSMS(lat,lon,id) {
  
    return new Promise((resolve, reject) => {

                twilio.messages.create({
                    body: `https://www.google.com/maps/search/?api=1&query=${lat},${lon}`,
                    to: `+94777594330`,  // Text this number
                    from: '+14404843729' // From a valid Twilio number
                })
                    .then((message) => {
                        updateincident(id);
                        resolve(message.sid);
                    })
                    .catch(e=>reject(e));

            }
        
        )

}

async function updateincident(id){
    
    const civilianevidence=await Civilianevidence.updateOne({iid: id},{
        $set:{
               status: true
           }
       });

       console.log(civilianevidence);
       
}

router.put('/web/civilian/update/:nic&:job&:phone', async(req,res)=>{

    const rnic=req.params.nic;
    const rjob=req.params.job;
    const phone=req.params.phone;

    const civilian=await Civilian.updateOne({nic: rnic},{
        $set:{
               job: rjob,
               mobile:phone
           }
       });

       res.send(civilian);

})

module.exports=router;