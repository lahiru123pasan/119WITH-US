// const accountSid = 'AC4c839df800de743fe6d14eeda91d5b25';
// const authToken = 'c212d5e37b11bdddfa35e0c6b27f3a3f';
// const client = require('../sms');

// client.messages
//   .create({
//      body: 'This is the ship that made the Kessel Run in fourteen parsecs?',
//      from: '+14404843729',
//      to: '+94772756262'
//    })
//   .then(message => console.log(message.sid));
const year = new Date().getFullYear();
	const month = (new Date().getMonth())+1;
    const date = new Date().getDate()+14;
    
    console.log(`${year}-${month}-${date}`);
    