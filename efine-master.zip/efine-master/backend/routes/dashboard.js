const express = require('express');
const router = express.Router();
const mongo=require ("mongoose");

const db=require('../db');

router.get('/count/civilian', (req,res)=>{

; 


});



router.get('/reports', (req,res)=>{

});

module.exports=router;