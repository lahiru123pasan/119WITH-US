const express=require('express');
const cors=require('cors');
const morgan=require('morgan');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');
app.use(cors());
app.use(morgan('tiny'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const dash = require('./routes/dashboard');
app.use('/dashboard', dash);
const policeman=require('./routes/police');
app.use('/api/police', policeman);
const civilian=require('./routes/civilian');
app.use('/api/civilian', civilian);
app.disable('etag');

app.use(express.static(path.join(__dirname, 'public')));

app.locals.pretty = true;

app.get('/', (req,res)=>{
    res.render('login');
});

const port=process.env.PORT || 5000;

app.listen(port, ()=>{

    console.log('Listening on',port);

});

